"""Standalone Benchmark: Cold-Start vs. Offline LQG Warm-Start vs. Receding-Horizon Warm-Start BCD-SMPC.

Strictly follows the equations in the manuscript with ZERO heuristic tightening caps:
  - Eq. (44): Subproblem 1 (V-step QP with exact uncapped tightening kappa_x * sx, kappa_u * su)
  - Eq. (45)-(46): Subproblem 2 (\tilde{L}_y-step SOCP via Preconditioned Matrix-CG)
  - Eq. (47)-(49): Subproblem 3 (\tilde{K}-step SOCP via Preconditioned Matrix-CG)
  - Eq. (56)-(57): BCD stopping criterion |J^{k+1} - J^k| / |J^k| < eps = 0.01

Evaluates three initialization regimes on the same host machine:
  1. Cold-Start (t = 0): Initialized from generic causal matrices (\tilde{L}_y^0 = -0.5 I, \tilde{K}^0 = +0.5 I).
  2. Offline LQG Warm-Start (t = 0, Remark 7): Initialized from offline stabilizing DARE gains (L_ss, K_lqr).
  3. Receding-Horizon Warm-Start (t = 1..T, Theorem 2): Initialized at step t from step (t-1)'s converged
     solution (\tilde{L}_{y,t-1}^*, \tilde{K}_{t-1}^*) and shifted nominal input sequence V_{t-1}^*.

Usage:
    python3 code/py/benchmark_warmstart.py
"""

from __future__ import annotations
import json
import os
import time
import numpy as np
import bcd_smpc as B


def check_surrogate_violations(P: dict, out: dict) -> tuple[float, float, int]:
    """Verify exact surrogate chance-constraint residuals in Eqs. (44), (45), (47)."""
    Wx, Wu = P["Wx_mat"], P["Wu_mat"]
    Xb = (P["Abar"] @ P["x0"] + P["Bbar"] @ out["V"]).ravel()
    max_vx, max_vu, n_viol = -1.0, -1.0, 0
    if Wx.shape[0] > 0:
        sx = P["kappa_x"] * np.sqrt(np.maximum(0.0, np.sum((Wx @ out["SigX"]) * Wx, axis=1)))
        vx_vec = Wx @ Xb + sx - P["bx_vec"]
        max_vx = float(np.max(vx_vec))
        n_viol += int(np.sum(vx_vec > 1e-4))
    if Wu.shape[0] > 0:
        su = P["kappa_u"] * np.sqrt(np.maximum(0.0, np.sum((Wu @ out["SigU"]) * Wu, axis=1)))
        vu_vec = Wu @ out["V"].ravel() + su - P["bu_vec"]
        max_vu = float(np.max(vu_vec))
        n_viol += int(np.sum(vu_vec > 1e-4))
    return max_vx, max_vu, n_viol


def run_benchmark(n_repeats: int = 10, T_receding: int = 15):
    results = {}
    cases = [
        ("Case 1 (2D Unstable, C=[1,0], N=8)", 1, 8, 101),
        ("Case 2 (2D State+Input Constrained, C=[1,0], N=8)", 2, 8, 201),
        ("Case 4 (6-DOF AutoRally Vehicle, nx=6, nu=2, ny=3, N=12, dt=120ms)", 4, 12, 401),
    ]

    for label, case_id, N_val, seed in cases:
        print("=" * 88)
        print(f"Benchmarking: {label}")
        print("=" * 88)
        P = B.setup(case=case_id, N=N_val)

        # 1. Cold-Start at t = 0
        _ = B.solve(P, warm_mode="cold")
        runs_cold = [B.solve(P, warm_mode="cold") for _ in range(n_repeats)]
        out_cold = runs_cold[-1]
        sim_cold = B.simulate(P, out_cold, n_samples=100, seed=seed)
        vx_c, vu_c, nv_c = check_surrogate_violations(P, out_cold)
        t_cold_tot = float(np.mean([r["time_total"] for r in runs_cold])) * 1000.0
        t_cold_it = float(np.mean([r["time_per_iter"] for r in runs_cold])) * 1000.0

        print(f"[1] Cold-Start (t=0, from +/-0.5I):")
        print(f"    BCD Iterations : {out_cold['n_iter']} (rel_hist = {[round(float(x), 3) for x in out_cold['rel_hist']]} %)")
        print(f"    Time per Iter  : {t_cold_it:.2f} ms | Total Step Time: {t_cold_tot:.2f} ms")
        print(f"    Costs & Cov    : J0 = {out_cold['J0']:.4f}, J_emp = {sim_cold['J_emp_mean']:.4f}, "
              f"Tr(SigX_N^emp) = {sim_cold['tr_SigX_N_emp']:.4f}, RMSE = {sim_cold['rmse_mean']:.4f}")
        print(f"    Violations     : Surrogate max(viol_x, viol_u) = ({vx_c:+.2e}, {vu_c:+.2e}) [{nv_c} violated], "
              f"Empirical MC = ({sim_cold['max_viol_x']*100:.1f}%, {sim_cold['max_viol_u']*100:.1f}%)")

        # 2. Offline LQG Warm-Start at t = 0 (Remark 7)
        _ = B.solve(P, warm_mode="lqg_warm")
        runs_lqg = [B.solve(P, warm_mode="lqg_warm") for _ in range(n_repeats)]
        out_lqg = runs_lqg[-1]
        sim_lqg = B.simulate(P, out_lqg, n_samples=100, seed=seed)
        vx_l, vu_l, nv_l = check_surrogate_violations(P, out_lqg)
        t_lqg_tot = float(np.mean([r["time_total"] for r in runs_lqg])) * 1000.0
        t_lqg_it = float(np.mean([r["time_per_iter"] for r in runs_lqg])) * 1000.0

        print(f"\n[2] Offline LQG Warm-Start (t=0, from stabilizing L_ss, K_lqr of Remark 7):")
        print(f"    BCD Iterations : {out_lqg['n_iter']} (rel_hist = {[round(float(x), 3) for x in out_lqg['rel_hist']]} %)")
        print(f"    Time per Iter  : {t_lqg_it:.2f} ms | Total Step Time: {t_lqg_tot:.2f} ms "
              f"({t_cold_tot / max(t_lqg_tot, 1e-9):.2f}x faster than Cold-Start)")
        print(f"    Costs & Cov    : J0 = {out_lqg['J0']:.4f}, J_emp = {sim_lqg['J_emp_mean']:.4f}, "
              f"Tr(SigX_N^emp) = {sim_lqg['tr_SigX_N_emp']:.4f}, RMSE = {sim_lqg['rmse_mean']:.4f}")
        print(f"    Violations     : Surrogate max(viol_x, viol_u) = ({vx_l:+.2e}, {vu_l:+.2e}) [{nv_l} violated], "
              f"Empirical MC = ({sim_lqg['max_viol_x']*100:.1f}%, {sim_lqg['max_viol_u']*100:.1f}%)")

        # 3. Closed-Loop Receding-Horizon Warm-Start across t = 1 .. T_receding (Theorem 2)
        xbar_t = P["x0"].copy()
        prev_out = out_lqg
        rh_tot_times, rh_it_times, rh_iters, rh_viols = [], [], [], []
        print(f"\n[3] Closed-Loop Receding-Horizon Warm-Start (t = 1 .. {T_receding}, Theorem 2):")
        for t_step in range(1, T_receding + 1):
            v0 = prev_out["V"][:P["nu"]]
            xbar_t = P["A"] @ xbar_t + P["B"] @ v0
            P_t = dict(P)
            P_t["x0"] = xbar_t.copy()
            P_t["mu_x0"] = xbar_t.copy()
            P_t["x0term_full"] = (P_t["Abar_full"] @ xbar_t).ravel()
            P_t["x0term"] = (P_t["Abar"] @ xbar_t).ravel()
            P_t["fv"] = 2.0 * (P_t["Bbar_full"].T @ P_t["Qbar_full"] @ P_t["x0term_full"])

            _ = B.solve(P_t, warm_mode="receding_warm", prev_out=prev_out)
            runs_rh = [B.solve(P_t, warm_mode="receding_warm", prev_out=prev_out) for _ in range(5)]
            out_t = runs_rh[-1]
            t_s_tot = float(np.mean([r["time_total"] for r in runs_rh])) * 1000.0
            t_s_it = float(np.mean([r["time_per_iter"] for r in runs_rh])) * 1000.0
            vx_t, vu_t, nv_t = check_surrogate_violations(P_t, out_t)

            rh_tot_times.append(t_s_tot)
            rh_it_times.append(t_s_it)
            rh_iters.append(int(out_t["n_iter"]))
            rh_viols.append(nv_t)
            if t_step <= 5 or t_step == T_receding:
                print(f"    Step t={t_step:2d} | n_iter={out_t['n_iter']} | J0={out_t['J0']:8.4f} | "
                      f"rel_last={out_t['rel_hist'][-1]:5.3f}% | surr_viol=({vx_t:+.2e}, {vu_t:+.2e}) | "
                      f"t_iter={t_s_it:5.2f}ms | t_total={t_s_tot:5.2f}ms")
            prev_out = out_t

        print(f"    --> Receding-Horizon Summary (t=1..{T_receding}):")
        print(f"        Mean BCD Iterations : {np.mean(rh_iters):.2f} (Min={np.min(rh_iters)}, Max={np.max(rh_iters)})")
        print(f"        Mean Time per Iter  : {np.mean(rh_it_times):.2f} ms")
        print(f"        Mean Total Step Time: {np.mean(rh_tot_times):.2f} ms (Median: {np.median(rh_tot_times):.2f} ms)")
        print(f"        Total Surrogate Viol: {sum(rh_viols)} / {T_receding}\n")

        results[f"case{case_id}"] = dict(
            cold_start=dict(
                n_iter=int(out_cold["n_iter"]),
                time_per_iter_ms=round(t_cold_it, 2),
                time_total_ms=round(t_cold_tot, 2),
                J0=round(out_cold["J0"], 4),
                J_emp=round(sim_cold["J_emp_mean"], 4),
                tr_SigX_N_emp=round(sim_cold["tr_SigX_N_emp"], 4),
                rmse=round(sim_cold["rmse_mean"], 4),
                surr_viol_x=round(vx_c, 6),
                surr_viol_u=round(vu_c, 6),
                emp_viol_x_pct=round(sim_cold["max_viol_x"] * 100.0, 1),
                emp_viol_u_pct=round(sim_cold["max_viol_u"] * 100.0, 1),
            ),
            lqg_warm_start=dict(
                n_iter=int(out_lqg["n_iter"]),
                time_per_iter_ms=round(t_lqg_it, 2),
                time_total_ms=round(t_lqg_tot, 2),
                J0=round(out_lqg["J0"], 4),
                J_emp=round(sim_lqg["J_emp_mean"], 4),
                tr_SigX_N_emp=round(sim_lqg["tr_SigX_N_emp"], 4),
                rmse=round(sim_lqg["rmse_mean"], 4),
                surr_viol_x=round(vx_l, 6),
                surr_viol_u=round(vu_l, 6),
                emp_viol_x_pct=round(sim_lqg["max_viol_x"] * 100.0, 1),
                emp_viol_u_pct=round(sim_lqg["max_viol_u"] * 100.0, 1),
            ),
            receding_horizon_warm_start=dict(
                mean_n_iter=round(float(np.mean(rh_iters)), 2),
                mean_time_per_iter_ms=round(float(np.mean(rh_it_times)), 2),
                mean_time_total_ms=round(float(np.mean(rh_tot_times)), 2),
                median_time_total_ms=round(float(np.median(rh_tot_times)), 2),
                total_surrogate_violations=int(sum(rh_viols)),
            ),
        )

    out_json = os.path.join(os.path.dirname(__file__), "..", "..", "results", "warmstart_benchmark.json")
    os.makedirs(os.path.dirname(out_json), exist_ok=True)
    with open(out_json, "w") as f:
        json.dump(results, f, indent=2)
    print(f"Saved complete benchmark report to: {os.path.abspath(out_json)}")


if __name__ == "__main__":
    run_benchmark()
