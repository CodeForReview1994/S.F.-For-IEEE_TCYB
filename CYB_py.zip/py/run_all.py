"""Reproduce all figures (Fig. 1 - Fig. 6) and quantitative tables (Tables I - V)
for the revised manuscript:

    "Output-Feedback Stochastic Model Predictive Control for Discrete-Time
     Stochastic Linear Systems via Block Coordinate Descent"

Usage:
    python3 run_all.py
"""

from __future__ import annotations

import json
import os
import time
import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse, Polygon

import bcd_smpc as B

VARIANTS = [
    ("proposed", False, False, "Proposed BCD-SMPC\n(time-varying $L_t$ and $K_t$)"),
    ("fixedK",   False, True,  "BCD-SMPC\n(time-varying $L_t$, fixed $K_t$)"),
    ("fixedL",   True,  False, "BCD-SMPC\n(time-varying $K_t$, fixed $L_t$)"),
    ("fixedKL",  True,  True,  "Constant-Gain SMPC\n(fixed $L_t$ and fixed $K_t$)"),
]

BASELINES = ["CS-SMPC", "RF-MPC", "DR-MPC", "DDRMPC", "Tube-MPC", "SDP-MPC"]


def draw_ellipse(ax, S, mu, n_sigma=3.0, **kw):
    w, U = np.linalg.eigh(0.5 * (S + S.T))
    w = np.clip(w, 0.0, None)
    ang = np.degrees(np.arctan2(U[1, -1], U[0, -1]))
    e = Ellipse(tuple(mu), 2 * n_sigma * np.sqrt(w[-1]),
                2 * n_sigma * np.sqrt(w[0]), angle=ang, fill=False, **kw)
    ax.add_patch(e)
    return e


def plot_panel_2d(ax, P, r, lim, show_legend=False, show_bound=False):
    N, nx = P["N"], P["nx"]
    Xbar = r["out"]["Xbar"].ravel()
    SigX_true = r["out"]["SigX_true"]
    draw_ellipse(ax, P["Sig_x0"], P["x0"].ravel(), 3.0, color="k", lw=0.95, zorder=4)
    for t in range(N):
        S_t = SigX_true[t * nx:(t + 1) * nx, t * nx:(t + 1) * nx]
        mu_t = Xbar[t * nx:(t + 1) * nx]
        draw_ellipse(ax, S_t, mu_t, 3.0, color="k", lw=0.95, zorder=4)

    X = r["sim"]["X"]
    for s in range(X.shape[0]):
        ax.plot(X[s, :, 0], X[s, :, 1], "-*", color=(0.58, 0.78, 0.98),
                ms=2.2, lw=0.4, zorder=2)

    ax.plot(X[:, -1, 0], X[:, -1, 1], "o", ms=3.8, mfc="#1b9e4b", mec="#1b9e4b",
            zorder=5, label="Terminal states")

    Xn = np.column_stack([P["x0"].ravel(), Xbar.reshape(N, nx).T])
    ax.plot(Xn[0], Xn[1], "r--o", lw=1.25, ms=4.8, mfc="w", zorder=6,
            label="Nominal trajectory")
    ax.plot([], [], "-*", color=(0.58, 0.78, 0.98), ms=3.5,
            label="Monte Carlo trajectories")
    ax.plot([], [], "k-", lw=1.0, label="$3\\sigma$ confidence ellipse")

    if show_bound:
        ax.axhline(2.0, color="#b22222", ls="-.", lw=1.15, zorder=4, label="Constraint $x_2 \\leq 2$")

    ax.set_xlim(lim[0], lim[1])
    ax.set_ylim(lim[2], lim[3])
    ax.set_xlabel("$x_1$ (Position)", fontsize=9.5)
    ax.set_ylabel("$x_2$ (Velocity)", fontsize=9.5)
    ax.tick_params(labelsize=8.5)
    ax.grid(True, ls=":", alpha=0.35)
    if show_legend:
        ax.legend(loc="lower left", fontsize=7.0, frameon=True, framealpha=0.90)


def track_centerline(s):
    """S-bend chicane race-track centerline (X_ref(s), Y_ref(s), psi_ref(s))."""
    s = np.asarray(s, dtype=float)
    L_chicane = 26.0
    amp = 2.6
    X_ref = s
    Y_ref = amp * np.sin(2.0 * np.pi * s / L_chicane)
    dY_ds = amp * (2.0 * np.pi / L_chicane) * np.cos(2.0 * np.pi * s / L_chicane)
    psi_ref = np.arctan(dY_ds)
    nx_vec = -np.sin(psi_ref)
    ny_vec = np.cos(psi_ref)
    return X_ref, Y_ref, psi_ref, nx_vec, ny_vec


def frenet_to_global(s, ey):
    X_ref, Y_ref, psi_ref, nx_vec, ny_vec = track_centerline(s)
    return X_ref + ey * nx_vec, Y_ref + ey * ny_vec, psi_ref


def save_both(fig, outdir_res, outdir_py, outdir_paper, name_res, name_paper):
    p1 = os.path.join(outdir_res, name_res)
    p2 = os.path.join(outdir_py, name_res)
    p3 = os.path.join(outdir_paper, name_paper)
    fig.savefig(p1, dpi=300, bbox_inches="tight")
    fig.savefig(p2, dpi=300, bbox_inches="tight")
    fig.savefig(p3, dpi=300, bbox_inches="tight")
    plt.close(fig)


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    root = os.path.abspath(os.path.join(here, "..", ".."))
    outdir_res = os.path.join(root, "results")
    outdir_py = os.path.join(root, "results", "py")
    outdir_paper = os.path.join(root, "paper")
    os.makedirs(outdir_res, exist_ok=True)
    os.makedirs(outdir_py, exist_ok=True)
    os.makedirs(outdir_paper, exist_ok=True)

    summary = {"cases": {}, "timing": {}, "baselines": {}, "sensitivity": {}, "non_gaussian": {}}

    # =========================================================================
    # 1. Section V-A: Case 1 & Case 2 (2D Weakly Unstable Partial-Obs System)
    # =========================================================================
    for case in (1, 2):
        P = B.setup(case=case, N=8, partial_obs=True)
        print(f"\n=== Section V-A: Case {case} (N=8, C=[1, 0]) ===")
        res_list = []
        summary["cases"][f"case{case}"] = []
        for idx, (vname, fL, fK, title) in enumerate(VARIANTS, start=1):
            _ = B.solve(P, fixed_L=fL, fixed_K=fK, verbose=False)
            t_runs = [B.solve(P, fixed_L=fL, fixed_K=fK, verbose=False) for _ in range(10)]
            out = t_runs[-1]
            out["time_per_iter"] = float(np.mean([r["time_per_iter"] for r in t_runs]))
            out["time_total"] = float(np.mean([r["time_total"] for r in t_runs]))
            sim = B.simulate(P, out, n_samples=100, seed=100 + case)
            res_list.append(dict(name=vname, title=title, out=out, sim=sim))
            rec = dict(
                strategy=vname,
                J0=round(out["J0"], 4),
                J_reg=round(out["J"], 4),
                J_emp=round(sim["J_emp_mean"], 4),
                J_emp_ci95=round(sim["J_emp_ci95"], 4),
                rmse=round(sim["rmse_mean"], 4),
                n_iter=int(out["n_iter"]),
                time_per_iter_ms=round(out["time_per_iter"] * 1000.0, 2),
                time_total_ms=round(out["time_total"] * 1000.0, 2),
                tr_SigX_N_pred=round(sim["tr_SigX_N_pred"], 4),
                tr_SigX_N_true=round(sim["tr_SigX_N_true"], 4),
                tr_SigX_N_emp=round(sim["tr_SigX_N_emp"], 4),
                conservatism_ratio=round(sim["conservatism_ratio"], 2),
                viol_x_pct=round(sim["max_viol_x"] * 100.0, 1),
                viol_u_pct=round(sim["max_viol_u"] * 100.0, 1),
                rel_hist=[round(float(x), 4) for x in out["rel_hist"]],
            )
            summary["cases"][f"case{case}"].append(rec)
            print(f"  {vname:<10} | J0={rec['J0']:8.4f} | J_emp={rec['J_emp']:8.4f} | "
                  f"it={rec['n_iter']} | t_tot={rec['time_total_ms']:6.2f}ms | "
                  f"tr(SigX_N)={rec['tr_SigX_N_pred']:.4f} (emp {rec['tr_SigX_N_emp']:.4f}) | "
                  f"viol(x,u)=({rec['viol_x_pct']}%, {rec['viol_u_pct']}%)")

        lim = (-6.2, 3.3, -1.5, 3.85) if case == 1 else (-6.2, 3.3, -1.5, 2.75)
        fig, axes = plt.subplots(2, 2, figsize=(7.8, 6.6))
        for k, (ax, r) in enumerate(zip(axes.ravel(), res_list)):
            plot_panel_2d(ax, P, r, lim, show_legend=(k == 0), show_bound=(case == 2))
            ax.set_title(r["title"], fontsize=9.5, fontweight="bold")
        fig.tight_layout()
        save_both(fig, outdir_res, outdir_py, outdir_paper,
                  f"Fig{case}_case{case}_trajectories.png", f"Fig.{case}.jpg")

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.6, 3.2))
        rel = res_list[0]["out"]["rel_hist"]
        ax1.plot(np.arange(1, len(rel) + 1), rel, "-o", color="#1f77b4", mfc="w", ms=6, lw=1.5,
                 label="Relative change (%)")
        ax1.axhline(P["eps"] * 100.0, color="#d62728", ls="--", lw=1.0, label="Threshold $\\varepsilon = 1\\%$")
        ax1.set_xlabel("BCD Iteration $k$", fontsize=9.5)
        ax1.set_ylabel("Relative Objective Change (%)", fontsize=9.5)
        ax1.set_title(f"(a) Case {case} BCD Convergence", fontsize=9.5, fontweight="bold")
        ax1.set_xticks(np.arange(1, len(rel) + 1))
        ax1.grid(True, ls=":", alpha=0.4)
        ax1.legend(fontsize=8.0)

        scales = [0.1, 0.5, 1.5, 3.0]
        colors = ["#2ca02c", "#1f77b4", "#ff7f0e", "#9467bd"]
        sens_records = []
        for sc, col in zip(scales, colors):
            P_sc = B.setup(case=case, N=8, partial_obs=True, init_scale=sc)
            out_sc = B.solve(P_sc, verbose=False)
            seq_with_0 = out_sc["obj_hist_with_init"]
            ax2.plot(np.arange(0, len(seq_with_0)), seq_with_0,
                     "-s", color=col, mfc="w", ms=5, lw=1.3,
                     label=f"$\\Sigma_E^0=\\Sigma_F^0={sc}I$")
            sens_records.append(dict(scale=sc, J0_final=round(out_sc["J0"], 4),
                                     n_iter=int(out_sc["n_iter"]),
                                     obj_hist=[round(float(v), 4) for v in seq_with_0]))
        summary["sensitivity"][f"case{case}"] = sens_records
        ax2.set_xlabel("BCD Iteration $k$ (including $k=0$ init)", fontsize=9.5)
        ax2.set_ylabel("Surrogate Objective $\\widetilde{J}_{\\sigma}$", fontsize=9.5)
        ax2.set_title(f"(b) Case {case} Initialization Sensitivity", fontsize=9.5, fontweight="bold")
        ax2.set_xticks(np.arange(0, len(seq_with_0)))
        ax2.set_yscale("log")
        ax2.grid(True, which="both", ls=":", alpha=0.4)
        ax2.legend(fontsize=7.5)
        fig.tight_layout()
        save_both(fig, outdir_res, outdir_py, outdir_paper,
                  f"Fig{case+2}_case{case}_convergence.png", f"Fig.{case+2}.jpg")

    P_term = B.setup(case=2, N=8, partial_obs=True)
    ti = P_term["terminal"]
    summary["terminal_case2"] = dict(
        K_f=np.round(ti["K_f"], 4).tolist(),
        L_f=np.round(ti["L_f"], 4).tolist(),
        P_f=np.round(ti["P_f"], 4).tolist(),
        rho_cl=round(ti["rho_cl"], 4),
        rho_obs=round(ti["rho_obs"], 4),
        Sig_x_bound=np.round(ti["Sig_x_bound"], 4).tolist(),
        bx_tight=np.round(ti["bx_tight"], 4).tolist(),
        bu_tight=np.round(ti["bu_tight"], 4).tolist(),
        alpha_f=round(ti["alpha_f"], 4),
    )

    # =========================================================================
    # 2. Section V-B: Computational Timing Sweep (N = 5, 10, 15, 20, 25) & Baselines
    # =========================================================================
    print("\n=== Section V-B: Timing Sweep Across Horizons N = 5, 10, 15, 20, 25 ===")
    Ns = [5, 10, 15, 20, 25]
    summary["timing"]["table1"] = []
    summary["timing"]["table2"] = []

    for N in Ns:
        row_t1 = {"N": N}
        for c in (1, 2):
            P_n = B.setup(case=c, N=N, partial_obs=True)
            _ = B.solve(P_n, verbose=False)
            runs = [B.solve(P_n, verbose=False) for _ in range(5)]
            t_iter = float(np.mean([r["time_per_iter"] for r in runs]))
            t_tot = float(np.mean([r["time_total"] for r in runs]))
            n_it = int(np.round(np.mean([r["n_iter"] for r in runs])))
            row_t1[f"case{c}_iter_s"] = round(t_iter, 4)
            row_t1[f"case{c}_total_s"] = round(t_tot, 4)
            row_t1[f"case{c}_n_iter"] = n_it
        summary["timing"]["table1"].append(row_t1)

        P_b = B.setup(case=1, N=N, partial_obs=True)
        row_t2 = {"N": N, "Ours_iter_s": row_t1["case1_iter_s"], "Ours_total_s": row_t1["case1_total_s"]}
        for bname in BASELINES:
            _ = B.solve_baseline(P_b, bname)
            bruns = [B.solve_baseline(P_b, bname) for _ in range(3)]
            row_t2[bname] = round(float(np.mean([r["time_total"] for r in bruns])), 4)
        summary["timing"]["table2"].append(row_t2)
        print(f"  N={N:2d} | Case1 iter={row_t1['case1_iter_s']:.4f}s, tot={row_t1['case1_total_s']:.4f}s | "
              f"Case2 tot={row_t1['case2_total_s']:.4f}s | "
              f"SDP-MPC={row_t2['SDP-MPC']:.4f}s, DR-MPC={row_t2['DR-MPC']:.4f}s")

    print("\n=== Section V-B: Quantitative Baselines Comparison (Fig. 5 & Table III) ===")
    P_comp = B.setup(case=2, N=6, partial_obs=True)
    methods_all = [("Ours", None)] + [(b, b) for b in BASELINES]
    comp_results = []
    summary["baselines"]["case2_N6"] = []

    for idx, (m_label, b_key) in enumerate(methods_all):
        if b_key is None:
            _ = B.solve(P_comp, verbose=False)
            runs = [B.solve(P_comp, verbose=False) for _ in range(10)]
            out_m = runs[-1]
            out_m["time_total"] = float(np.mean([r["time_total"] for r in runs]))
            out_m["time_per_iter"] = float(np.mean([r["time_per_iter"] for r in runs]))
        else:
            _ = B.solve_baseline(P_comp, b_key)
            runs = [B.solve_baseline(P_comp, b_key) for _ in range(5)]
            out_m = runs[-1]
            out_m["time_total"] = float(np.mean([r["time_total"] for r in runs]))
        sim_m = B.simulate(P_comp, out_m, n_samples=100, seed=200)
        comp_results.append((m_label, out_m, sim_m))
        rec_b = dict(
            method=m_label,
            J0=round(out_m["J0"], 4),
            J_emp=round(sim_m["J_emp_mean"], 4),
            J_emp_ci95=round(sim_m["J_emp_ci95"], 4),
            rmse=round(sim_m["rmse_mean"], 4),
            tr_SigX_N_pred=round(sim_m["tr_SigX_N_pred"], 4),
            tr_SigX_N_true=round(sim_m["tr_SigX_N_true"], 4),
            tr_SigX_N_emp=round(sim_m["tr_SigX_N_emp"], 4),
            viol_x_pct=round(sim_m["max_viol_x"] * 100.0, 1),
            viol_u_pct=round(sim_m["max_viol_u"] * 100.0, 1),
            n_iter=int(out_m["n_iter"]),
            time_total_s=round(out_m["time_total"], 4),
        )
        summary["baselines"]["case2_N6"].append(rec_b)
        print(f"  {m_label:<9} | J_emp={rec_b['J_emp']:8.4f} | J0={rec_b['J0']:8.4f} | "
              f"RMSE={rec_b['rmse']:.4f} | tr(SigX_N)={rec_b['tr_SigX_N_emp']:.4f} | "
              f"viol=({rec_b['viol_x_pct']}%, {rec_b['viol_u_pct']}%) | t={rec_b['time_total_s']:.4f}s")

    fig = plt.figure(figsize=(10.6, 8.8))
    gs5 = fig.add_gridspec(3, 6, height_ratios=[1.0, 1.0, 1.0], hspace=0.46, wspace=0.85)
    lim5 = (-6.0, 2.2, -1.2, 2.7)
    panel_letters = ["(a)", "(b)", "(c)", "(d)", "(e)", "(f)"]
    # comp_results[0] is Ours; comp_results[1:7] are the 6 competing baselines
    for k_idx, (m_label, out_m, sim_m) in enumerate(comp_results[1:7]):
        r_row = k_idx // 3
        c_col = (k_idx % 3) * 2
        ax = fig.add_subplot(gs5[r_row, c_col:c_col + 2])
        r_obj = {"out": out_m, "sim": sim_m}
        plot_panel_2d(ax, P_comp, r_obj, lim5, show_legend=(k_idx == 0), show_bound=True)
        ax.set_title(f"{panel_letters[k_idx]} {m_label}", fontsize=9.2, fontweight="bold")

    # Panel (g): All 7 methods mean/nominal trajectories in a single comparison plot
    ax_g = fig.add_subplot(gs5[2, 0:3])
    m_Palette = {
        "Ours":     ("-o",  "#d62728", 1.8, "Proposed BCD-SMPC (Ours)"),
        "CS-SMPC":  ("--s", "#1f77b4", 1.3, "CS-SMPC"),
        "RF-MPC":   ("-.^", "#2ca02c", 1.3, "RF-MPC"),
        "DR-MPC":   (":d",  "#9467bd", 1.3, "DR-MPC"),
        "DDRMPC":   ("--v", "#ff7f0e", 1.3, "DDRMPC"),
        "Tube-MPC": ("-.p", "#7f7f7f", 1.3, "Tube-MPC"),
        "SDP-MPC":  (":*",  "#8c564b", 1.4, "SDP-MPC"),
    }
    ax_g.axhline(2.0, color="#b22222", ls="-.", lw=1.15, label="Constraint $x_2 \leq 2$")
    for m_label, out_m, sim_m in comp_results:
        ls_m, col_m, lw_m, lbl_m = m_Palette[m_label]
        X_mean = np.mean(sim_m["X"], axis=0)  # empirical mean trajectory (N+1, 2)
        ax_g.plot(X_mean[:, 0], X_mean[:, 1], ls_m, color=col_m, lw=lw_m, ms=4.2,
                  mfc=("w" if m_label == "Ours" else col_m), zorder=(6 if m_label == "Ours" else 4), label=lbl_m)
    ax_g.set_xlim(-5.4, 0.6)
    ax_g.set_ylim(-0.25, 2.25)
    ax_g.set_xlabel("$x_1$ (Position)", fontsize=9.2)
    ax_g.set_ylabel("$x_2$ (Velocity)", fontsize=9.2)
    ax_g.set_title("(g) Mean Trajectory Comparison Across All 7 Methods", fontsize=9.2, fontweight="bold")
    ax_g.grid(True, ls=":", alpha=0.4)
    ax_g.legend(loc="lower left", fontsize=6.5, ncol=2, frameon=True, framealpha=0.92)

    # Panel (h): Terminal 3-sigma covariance ellipses centered at origin (0, 0) for direct size comparison
    ax_h = fig.add_subplot(gs5[2, 3:6])
    for m_label, out_m, sim_m in comp_results:
        ls_m, col_m, lw_m, lbl_m = m_Palette[m_label]
        S_N = out_m["SigX_true"][-2:, -2:]
        draw_ellipse(ax_h, S_N, (0.0, 0.0), 3.0, color=col_m, ls=ls_m.replace("o","").replace("s","").replace("^","").replace("d","").replace("v","").replace("p","").replace("*",""), lw=lw_m)
        ax_h.plot([], [], ls_m, color=col_m, lw=lw_m, label=f"{lbl_m} ($\mathrm{{Tr}}={sim_m['tr_SigX_N_emp']:.3f}$)")
    ax_h.set_xlim(-2.68, 2.68)
    ax_h.set_ylim(-1.12, 1.88)
    ax_h.set_xlabel(r"Terminal Position Error $\tilde{x}_{1,N}$", fontsize=9.2)
    ax_h.set_ylabel(r"Terminal Velocity Error $\tilde{x}_{2,N}$", fontsize=9.2)
    ax_h.set_title("(h) Terminal $3\sigma$ Covariance Ellipse Comparison", fontsize=9.2, fontweight="bold")
    ax_h.grid(True, ls=":", alpha=0.4)
    ax_h.legend(loc="upper center", fontsize=5.8, ncol=2, frameon=True, framealpha=0.92)

    save_both(fig, outdir_res, outdir_py, outdir_paper,
              "Fig5_baselines_comparison.png", "Fig.5.jpg")

    for dist_law in ("gaussian", "laplace", "student_t", "uniform"):
        P_ng = B.setup(case=2, N=8, partial_obs=True,
                       dist_type=("gaussian" if dist_law == "gaussian" else "cantelli"))
        out_ng = B.solve(P_ng, verbose=False)
        sim_ng = B.simulate(P_ng, out_ng, n_samples=200, seed=303, noise_law=dist_law)
        summary["non_gaussian"][dist_law] = dict(
            tightening=("Gaussian CDF" if dist_law == "gaussian" else "Cantelli Bound"),
            kappa_x=round(P_ng["kappa_x"], 4),
            J_emp=round(sim_ng["J_emp_mean"], 4),
            tr_SigX_N_emp=round(sim_ng["tr_SigX_N_emp"], 4),
            viol_x_pct=round(sim_ng["max_viol_x"] * 100.0, 1),
            viol_u_pct=round(sim_ng["max_viol_u"] * 100.0, 1),
        )

    # =========================================================================
    # 3. Section V-C: 6-DOF AutoRally Autonomous Off-Road Racing Vehicle Race-Track Control
    # =========================================================================
    print("\n=== Section V-C: 6-DOF AutoRally Autonomous Off-Road Racing Vehicle Race-Track Trajectory Tracking ===")
    P_veh = B.setup(case=4, N=12)
    veh_variants = []
    summary["cases"]["case4_vehicle"] = []
    for idx, (vname, fL, fK, title) in enumerate(VARIANTS, start=1):
        _ = B.solve(P_veh, fixed_L=fL, fixed_K=fK, verbose=False)
        runs = [B.solve(P_veh, fixed_L=fL, fixed_K=fK, verbose=False) for _ in range(5)]
        out_v = runs[-1]
        out_v["time_total"] = float(np.mean([r["time_total"] for r in runs]))
        out_v["time_per_iter"] = float(np.mean([r["time_per_iter"] for r in runs]))
        # Measure closed-loop receding-horizon warm-start time (t=1..15, Theorem 2) for each variant
        prev_v = B.solve(P_veh, fixed_L=fL, fixed_K=fK, warm_mode="lqg_warm", verbose=False)
        xbar_v = P_veh["x0"].copy()
        rh_times_v = []
        for _t_rh in range(1, 16):
            v0_v = prev_v["V"][:P_veh["nu"]]
            xbar_v = P_veh["A"] @ xbar_v + P_veh["B"] @ v0_v
            P_tv = dict(P_veh)
            P_tv["x0"] = xbar_v.copy()
            P_tv["mu_x0"] = xbar_v.copy()
            P_tv["x0term_full"] = (P_tv["Abar_full"] @ xbar_v).ravel()
            P_tv["x0term"] = (P_tv["Abar"] @ xbar_v).ravel()
            P_tv["fv"] = 2.0 * (P_tv["Bbar_full"].T @ P_tv["Qbar_full"] @ P_tv["x0term_full"])
            _ = B.solve(P_tv, fixed_L=fL, fixed_K=fK, warm_mode="receding_warm", prev_out=prev_v, verbose=False)
            runs_rh_v = [B.solve(P_tv, fixed_L=fL, fixed_K=fK, warm_mode="receding_warm", prev_out=prev_v, verbose=False) for _ in range(3)]
            prev_v = runs_rh_v[-1]
            rh_times_v.append(float(np.mean([r["time_total"] for r in runs_rh_v])) * 1000.0)
        time_warm_ms = round(float(np.mean(rh_times_v)), 2)

        sim_v = B.simulate(P_veh, out_v, n_samples=100, seed=400)
        veh_variants.append((vname, title, out_v, sim_v))
        rec_v = dict(
            strategy=vname,
            J0=round(out_v["J0"], 4),
            J_emp=round(sim_v["J_emp_mean"], 4),
            rmse=round(sim_v["rmse_mean"], 4),
            n_iter=int(out_v["n_iter"]),
            time_per_iter_ms=round(out_v["time_per_iter"] * 1000.0, 2),
            time_total_ms=round(out_v["time_total"] * 1000.0, 2),
            time_receding_warm_ms=time_warm_ms,
            tr_SigX_N_pred=round(sim_v["tr_SigX_N_pred"], 4),
            tr_SigX_N_true=round(sim_v["tr_SigX_N_true"], 4),
            tr_SigX_N_emp=round(sim_v["tr_SigX_N_emp"], 4),
            rmse_nl_rk4=round(sim_v.get("rmse_nl_rk4", sim_v["rmse_mean"]), 4),
            tr_SigX_N_nl_rk4=round(sim_v.get("tr_SigX_N_nl_rk4", sim_v["tr_SigX_N_emp"]), 4),
            viol_x_pct=round(sim_v["max_viol_x"] * 100.0, 1),
            viol_u_pct=round(sim_v["max_viol_u"] * 100.0, 1),
        )
        summary["cases"]["case4_vehicle"].append(rec_v)
        print(f"  Race {vname:<10} | J0={rec_v['J0']:8.4f} | J_emp={rec_v['J_emp']:8.4f} | "
              f"RMSE={rec_v['rmse']:.4f} | tr(SigX_N)={rec_v['tr_SigX_N_pred']:.4f} "
              f"(emp {rec_v['tr_SigX_N_emp']:.4f}) | viol=({rec_v['viol_x_pct']}%, {rec_v['viol_u_pct']}%) | "
              f"t_tot={rec_v['time_total_ms']:.2f}ms")

    print("\n=== Section V-C: 6-DOF Racing Vehicle Competing Baselines Comparison (Table IV) ===")
    veh_baselines = [("Ours", veh_variants[0][2], veh_variants[0][3])]
    summary["baselines"]["case4_vehicle"] = [dict(
        method="Ours",
        J0=round(veh_variants[0][2]["J0"], 4),
        J_emp=round(veh_variants[0][3]["J_emp_mean"], 4),
        rmse=round(veh_variants[0][3]["rmse_mean"], 4),
        J_emp_ci95=round(veh_variants[0][3]["J_emp_ci95"], 4),
        tr_SigX_N_true=round(veh_variants[0][3]["tr_SigX_N_true"], 4),
        tr_SigX_N_emp=round(veh_variants[0][3]["tr_SigX_N_emp"], 4),
        rmse_nl_rk4=round(veh_variants[0][3].get("rmse_nl_rk4", veh_variants[0][3]["rmse_mean"]), 4),
        tr_SigX_N_nl_rk4=round(veh_variants[0][3].get("tr_SigX_N_nl_rk4", veh_variants[0][3]["tr_SigX_N_emp"]), 4),
        viol_x_pct=round(veh_variants[0][3]["max_viol_x"] * 100.0, 1),
        viol_u_pct=round(veh_variants[0][3]["max_viol_u"] * 100.0, 1),
        time_total_ms=round(veh_variants[0][2]["time_total"] * 1000.0, 2),
    )]
    VEH_BASELINES = ["CS-SMPC", "RF-MPC", "DR-MPC", "DDRMPC", "Tube-MPC", "SDP-MPC"]
    for b_idx, b_key in enumerate(VEH_BASELINES, start=1):
        n_rep = 1 if b_key == "SDP-MPC" else 3
        bruns = [B.solve_baseline(P_veh, b_key) for _ in range(n_rep)]
        out_vb = bruns[-1]
        out_vb["time_total"] = float(np.mean([r["time_total"] for r in bruns]))
        sim_vb = B.simulate(P_veh, out_vb, n_samples=100, seed=400)
        veh_baselines.append((b_key, out_vb, sim_vb))
        rec_vb = dict(
            method=b_key,
            J0=round(out_vb["J0"], 4),
            J_emp=round(sim_vb["J_emp_mean"], 4),
            rmse=round(sim_vb["rmse_mean"], 4),
            J_emp_ci95=round(sim_vb["J_emp_ci95"], 4),
            tr_SigX_N_true=round(sim_vb["tr_SigX_N_true"], 4),
            tr_SigX_N_emp=round(sim_vb["tr_SigX_N_emp"], 4),
            rmse_nl_rk4=round(sim_vb.get("rmse_nl_rk4", sim_vb["rmse_mean"]), 4),
            tr_SigX_N_nl_rk4=round(sim_vb.get("tr_SigX_N_nl_rk4", sim_vb["tr_SigX_N_emp"]), 4),
            viol_x_pct=round(sim_vb["max_viol_x"] * 100.0, 1),
            viol_u_pct=round(sim_vb["max_viol_u"] * 100.0, 1),
            time_total_ms=round(out_vb["time_total"] * 1000.0, 2),
        )
        summary["baselines"]["case4_vehicle"].append(rec_vb)
        print(f"  VehBase {b_key:<9} | J_emp={rec_vb['J_emp']:8.4f} | J0={rec_vb['J0']:8.4f} | "
              f"RMSE={rec_vb['rmse']:.4f} | tr(SigX_N)={rec_vb['tr_SigX_N_emp']:.4f} | "
              f"viol=({rec_vb['viol_x_pct']}%, {rec_vb['viol_u_pct']}%) | t={rec_vb['time_total_ms']:.2f}ms")

    # Helper to render a race-track chicane panel with 100 Monte Carlo trajectories & 3-sigma ellipses
    N_v, nx_v = P_veh["N"], P_veh["nx"]
    w_bound = P_veh["track_half_width"]  # 0.65 m
    s_nodes = np.linspace(0.0, 25.92, N_v + 1)
    s_dense = np.linspace(-0.8, s_nodes[-1] + 1.0, 300)
    X_ref_d, Y_ref_d, psi_ref_d, nx_d, ny_d = track_centerline(s_dense)
    vis_scale = 2.0
    X_up_vis, Y_up_vis = X_ref_d + (w_bound * vis_scale) * nx_d, Y_ref_d + (w_bound * vis_scale) * ny_d
    X_lo_vis, Y_lo_vis = X_ref_d - (w_bound * vis_scale) * nx_d, Y_ref_d - (w_bound * vis_scale) * ny_d

    def plot_race_chicane_panel(ax_p, out_v, sim_v, panel_tag, show_legend=False):
        poly_pts = np.vstack([
            np.column_stack([X_up_vis, Y_up_vis]),
            np.column_stack([X_lo_vis[::-1], Y_lo_vis[::-1]]),
        ])
        ax_p.add_patch(Polygon(poly_pts, closed=True, facecolor="#e6eaef", edgecolor="none", zorder=0))
        ax_p.plot(X_up_vis, Y_up_vis, color="#b22222", ls="-.", lw=1.3, zorder=3,
                  label="Track boundary ($|e_y| \leq 0.65$ m)")
        ax_p.plot(X_lo_vis, Y_lo_vis, color="#b22222", ls="-.", lw=1.3, zorder=3)
        ax_p.plot(X_ref_d, Y_ref_d, color="#2ca02c", ls=":", lw=1.3, zorder=2,
                  label="Optimal racing line ($e_y = 0$)")
        ax_p.text(6.5, 4.18, "Turn 1 Apex", fontsize=7.2, fontweight="bold", color="#2c3e50", ha="center")
        ax_p.text(19.5, -0.75, "Turn 2 Apex", fontsize=7.2, fontweight="bold", color="#2c3e50", ha="center")

        Xbar_v = out_v["Xbar"].ravel().reshape(N_v, nx_v)
        ey_nom = np.concatenate([[P_veh["x0"][0, 0]], Xbar_v[:, 0]])
        s_nom = s_nodes + np.concatenate([[P_veh["x0"][5, 0]], Xbar_v[:, 5]]) * vis_scale
        X_nom, Y_nom, psi_nodes = frenet_to_global(s_nom, ey_nom * vis_scale)

        Xv = sim_v["X"]
        for s_idx in range(Xv.shape[0]):
            ey_s = Xv[s_idx, :, 0] * vis_scale
            s_traj = s_nodes + Xv[s_idx, :, 5] * vis_scale
            Xs, Ys, _ = frenet_to_global(s_traj, ey_s)
            ax_p.plot(Xs, Ys, "-", color=(0.55, 0.76, 0.98), lw=0.42, zorder=2)

        SigX_true = out_v["SigX_true"]
        sig_y0 = np.sqrt(max(1e-6, P_veh["Sig_x0"][0, 0])) * vis_scale
        sig_s0 = np.sqrt(max(1e-6, P_veh["Sig_x0"][5, 5])) * vis_scale
        ell0 = Ellipse((X_nom[0], Y_nom[0]), width=2 * 3.0 * sig_s0, height=2 * 3.0 * sig_y0,
                       angle=np.degrees(psi_nodes[0]), fill=False, edgecolor="k", lw=0.95, zorder=5)
        ax_p.add_patch(ell0)
        for t in range(N_v):
            S_t = SigX_true[t * nx_v:(t + 1) * nx_v, t * nx_v:(t + 1) * nx_v]
            sig_y = np.sqrt(max(1e-6, S_t[0, 0])) * vis_scale
            sig_s = np.sqrt(max(1e-6, S_t[5, 5])) * vis_scale
            ell = Ellipse((X_nom[t + 1], Y_nom[t + 1]), width=2 * 3.0 * sig_s,
                          height=2 * 3.0 * sig_y, angle=np.degrees(psi_nodes[t + 1]),
                          fill=False, edgecolor="k", lw=0.95, zorder=5)
            ax_p.add_patch(ell)

        X_term, Y_term, _ = frenet_to_global(
            s_nodes[-1] + Xv[:, -1, 5] * vis_scale, Xv[:, -1, 0] * vis_scale
        )
        ax_p.plot(X_term, Y_term, "o", ms=3.4, mfc="#1b9e4b", mec="#1b9e4b",
                  zorder=5, label="Terminal vehicle positions")
        ax_p.plot(X_nom, Y_nom, "r--o", lw=1.35, ms=4.0, mfc="w", zorder=6,
                  label="Nominal trajectory")
        ax_p.plot([], [], "k-", lw=1.0, label="$3\sigma$ position uncertainty ellipse")

        ax_p.set_xlim(-1.2, 27.5)
        ax_p.set_ylim(-5.85, 4.95)
        ax_p.set_xlabel("Track Longitudinal Coordinate $X$ [m]", fontsize=8.8)
        ax_p.set_ylabel("Track Lateral Coordinate $Y$ [m]", fontsize=8.8)
        ax_p.set_title(panel_tag, fontsize=9.0, fontweight="bold")
        ax_p.grid(True, ls=":", alpha=0.35)
        if show_legend:
            ax_p.legend(loc="lower left", fontsize=6.0, ncol=1, frameon=True, framealpha=0.92)

    # Plot Fig. 6: 2x2 Gain-Strategy Ablation on the 6-DOF AutoRally Off-Road Race Track
    fig6, axes6 = plt.subplots(2, 2, figsize=(9.6, 6.6))
    tags6 = [
        "(a) Proposed BCD-SMPC (time-varying $L_t$ and $K_t$)",
        "(b) BCD-SMPC (time-varying $L_t$, fixed $K_t$)",
        "(c) BCD-SMPC (time-varying $K_t$, fixed $L_t$)",
        "(d) Constant-Gain SMPC (fixed $L_t$ and fixed $K_t$)",
    ]
    for idx_p, (ax_p, (_, _, out_v, sim_v), ptag) in enumerate(zip(axes6.ravel(), veh_variants, tags6)):
        plot_race_chicane_panel(ax_p, out_v, sim_v, ptag, show_legend=(idx_p == 0))
    fig6.tight_layout()
    save_both(fig6, outdir_res, outdir_py, outdir_paper,
              "Fig6_vehicle_trajectories.png", "Fig.6.jpg")

    # Plot Fig. 7: Symmetrical 6-Baseline Race-Track Comparison + Mean Trajectory & Terminal Ellipse Comparison
    fig7 = plt.figure(figsize=(11.4, 9.0))
    gs7 = fig7.add_gridspec(3, 6, height_ratios=[1.0, 1.0, 1.0], hspace=0.46, wspace=0.85)
    # veh_baselines[0] is Ours; veh_baselines[1:7] are the 6 competing baselines
    for idx_b, (m_label, out_vb, sim_vb) in enumerate(veh_baselines[1:7]):
        r_row = idx_b // 3
        c_col = (idx_b % 3) * 2
        ax_p = fig7.add_subplot(gs7[r_row, c_col:c_col + 2])
        plot_race_chicane_panel(ax_p, out_vb, sim_vb, f"{panel_letters[idx_b]} {m_label}", show_legend=(idx_b == 0))

    # Panel (g): Mean Cross-Track Error Trajectory e_y(s) Across All 7 Methods (Ours + 6 Baselines)
    ax_7g = fig7.add_subplot(gs7[2, 0:3])
    ax_7g.axhline(w_bound, color="#b22222", ls="-.", lw=1.15, label="Track boundary $|e_y| \leq 0.65$ m")
    ax_7g.axhline(-w_bound, color="#b22222", ls="-.", lw=1.15)
    ax_7g.axhline(0.0, color="#2ca02c", ls=":", lw=1.0, label="Optimal racing line ($e_y = 0$)")
    for m_label, out_vb, sim_vb in veh_baselines:
        ls_m, col_m, lw_m, lbl_m = m_Palette[m_label]
        ey_mean = np.mean(sim_vb["X"][:, :, 0], axis=0)
        ax_7g.plot(s_nodes, ey_mean, ls_m, color=col_m, lw=lw_m, ms=3.8,
                   mfc=("w" if m_label == "Ours" else col_m), zorder=(6 if m_label == "Ours" else 4), label=lbl_m)
    ax_7g.set_xlim(0.0, s_nodes[-1])
    ax_7g.set_ylim(-0.72, 0.72)
    ax_7g.set_xlabel("Curvilinear Track Distance $s$ [m]", fontsize=9.0)
    ax_7g.set_ylabel("Mean Cross-Track Error $e_y(s)$ [m]", fontsize=9.0)
    ax_7g.set_title("(g) Mean Cross-Track Trajectory $e_y(s)$ Across All 7 Methods", fontsize=9.2, fontweight="bold")
    ax_7g.grid(True, ls=":", alpha=0.4)
    ax_7g.legend(loc="upper right", fontsize=5.8, ncol=2, frameon=True, framealpha=0.92)

    # Panel (h): Terminal 3-sigma Covariance Ellipse in (e_y, v_y) Across All 7 Methods
    ax_7h = fig7.add_subplot(gs7[2, 3:6])
    idx_ey_vy = np.ix_([0, 1], [0, 1])
    for m_label, out_vb, sim_vb in veh_baselines:
        ls_m, col_m, lw_m, lbl_m = m_Palette[m_label]
        S_N6 = out_vb["SigX_true"][-nx_v:, -nx_v:]
        S_sub = S_N6[idx_ey_vy]
        draw_ellipse(ax_7h, S_sub, (0.0, 0.0), 3.0, color=col_m,
                     ls=ls_m.replace("o","").replace("s","").replace("^","").replace("d","").replace("v","").replace("p","").replace("*",""), lw=lw_m)
        ax_7h.plot([], [], ls_m, color=col_m, lw=lw_m, label=f"{lbl_m} ($\mathrm{{Tr}}={sim_vb['tr_SigX_N_emp']:.3f}$)")
    ax_7h.set_xlim(-0.82, 0.82)
    ax_7h.set_ylim(-0.48, 0.76)
    ax_7h.set_xlabel(r"Terminal Lateral Error $\tilde{e}_{y,N}$ [m]", fontsize=9.0)
    ax_7h.set_ylabel(r"Terminal Lateral Velocity $\tilde{v}_{y,N}$ [m/s]", fontsize=9.0)
    ax_7h.set_title("(h) Terminal $3\sigma$ Covariance Ellipse Comparison", fontsize=9.2, fontweight="bold")
    ax_7h.grid(True, ls=":", alpha=0.4)
    ax_7h.legend(loc="upper center", fontsize=5.6, ncol=2, frameon=True, framealpha=0.92)

    save_both(fig7, outdir_res, outdir_py, outdir_paper,
              "Fig7_vehicle_baselines_comparison.png", "Fig.7.jpg")


    # =========================================================================
    # 4. Closed-Loop Receding-Horizon Dual-Initialization Verification (Eq. 58)
    #    & 300-Run Randomized Initialization Sensitivity & Unscaled DARE Control
    # =========================================================================
    print("\n=== Closed-Loop Receding-Horizon Simulation (Eq. 58 Strategy 1 / 2 Usage) ===")
    cl_res2 = B.simulate_closed_loop(P_comp, T_steps=16, n_samples=40, seed=42)
    summary["closed_loop_case2"] = dict(
        T_steps=16,
        n_samples=40,
        strat1_count=int(cl_res2["strat1_count"]),
        strat2_count=int(cl_res2["strat2_count"]),
        strat1_pct=float(cl_res2["strat1_pct"]),
        strat2_pct=float(cl_res2["strat2_pct"]),
    )
    print(f"  Case 2 Closed-Loop: Strategy 1 = {cl_res2['strat1_pct']:.1f}%, Strategy 2 = {cl_res2['strat2_pct']:.1f}%")

    # Also log Strategy 1 / 2 usage on each row of Table III (case2_N6):
    for rec_b in summary["baselines"]["case2_N6"]:
        if rec_b["method"] == "Ours":
            rec_b["strat1_pct"] = float(cl_res2["strat1_pct"])
            rec_b["strat2_pct"] = float(cl_res2["strat2_pct"])

    print("\n=== 300-Run Randomized Initialization Sensitivity (c in [0.05, 2.0]) ===")
    c_grid = np.linspace(0.05, 2.0, 300)
    j0_300 = []
    for c_val in c_grid:
        P_300 = B.setup(case=2, N=8, partial_obs=True, init_scale=float(c_val))
        out_300 = B.solve(P_300, verbose=False)
        j0_300.append(float(out_300["J0"]))
    j0_300 = np.array(j0_300)
    rel_std_300 = float(np.std(j0_300) / max(np.mean(j0_300), 1e-12) * 100.0)
    summary["sensitivity"]["random_300_case2"] = dict(
        n_runs=300,
        c_min=0.05,
        c_max=2.0,
        J0_mean=round(float(np.mean(j0_300)), 6),
        J0_std=round(float(np.std(j0_300)), 6),
        J0_rel_std_pct=round(rel_std_300, 4),
    )
    print(f"  300-Run Sensitivity: J0_mean={np.mean(j0_300):.4f}, J0_std={np.std(j0_300):.6f}, rel_std={rel_std_300:.4f}%")

    print("\n=== Unscaled DARE (L_base = 1.0 * L_ss, K_base = 1.0 * K_lqr) Baseline Control Experiment ===")
    summary["baselines_unscaled_dare"] = {"case2_N6": [], "case4_vehicle": []}
    for tag_u, P_u in [("case2_N6", B.setup(case=2, N=6, partial_obs=True)), ("case4_vehicle", B.setup(case=4, N=12))]:
        P_u["L_base"] = P_u["L_ss"].copy()
        P_u["K_base"] = P_u["K_lqr"].copy()
        seed_u = 200 if tag_u == "case2_N6" else 400
        for m_label, b_key in [("Ours", None)] + [(b, b) for b in BASELINES]:
            out_u = B.solve(P_u, verbose=False) if b_key is None else B.solve_baseline(P_u, b_key)
            sim_u = B.simulate(P_u, out_u, n_samples=100, seed=seed_u)
            summary["baselines_unscaled_dare"][tag_u].append(dict(
                method=m_label,
                J_emp=round(sim_u["J_emp_mean"], 4),
                J_emp_ci95=round(sim_u["J_emp_ci95"], 4),
                tr_SigX_N_emp=round(sim_u["tr_SigX_N_emp"], 4),
                tr_SigX_N_true=round(sim_u["tr_SigX_N_true"], 4),
                rmse=round(sim_u["rmse_mean"], 4),
                viol_x_pct=round(sim_u["max_viol_x"] * 100.0, 1),
                viol_u_pct=round(sim_u["max_viol_u"] * 100.0, 1),
            ))

    with open(os.path.join(outdir_res, "summary_metrics.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print("\nAll figures (Fig.1 - Fig.6) and summary_metrics.json generated successfully.")


if __name__ == "__main__":
    main()
