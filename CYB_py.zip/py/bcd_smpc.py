"""BCD-based output-feedback stochastic MPC -- Reference Python Implementation.

Solves the three convex sub-problems of:
    "Output-Feedback Stochastic Model Predictive Control for Discrete-Time
     Stochastic Linear Systems via Block Coordinate Descent"

Key Mathematical & Implementation Guarantees:
1. Exact (N+1)-block prediction matrices (p_full = (N+1)*nx, py_full = (N+1)*ny,
   mu = N*nu) matching Appendix A and Eqs. (8a)-(8f), (37a)-(40) with zero index
   shift between the block-matrix formulation and step-by-step causal recursion.
2. Exact unscaled proximal regularization terms (sigma/2)||V - V^k||_2^2,
   (sigma/2)||Ltilde_y - Ltilde_y^k||_F^2, and (sigma/2)||Ktilde - Ktilde^k||_F^2
   in Eqs. (43a)-(43c), (44), (45), and (47) (with 100% consistent sigma across all
   three blocks), full coupled weight matrix W_L^k in Eq. (45), and exact stopping
   criterion Eq. (56) using f(V^k, Ltilde_y^k, Ktilde^k) (Eq. 57).
3. Exact offline terminal distribution covariance constraints Eqs. (53)-(55) enforced
   via directional spectral-cone dual updates in both Subproblem 2 (solve_L, Eq. 54)
   and Subproblem 3 (solve_K, Eq. 55) with fixed offline Sigma_{x,N} (no self-relaxation).
4. Exact 6-DOF AutoRally curvilinear dynamic bicycle + Pacejka Magic Formula nonlinear
   tracking-error dynamics f_veh_6dof(x, u) (Eqs. veh_6dof & pacejka), where x_eq = 0
   is a true equilibrium (f(0, 0) = 0 identically) and rk4_step_veh_6dof integrates
   the exact nonlinear ODE via 4th-order Runge-Kutta without drift subtraction.
5. Faithful implementations of all 6 competing baselines (CS-SMPC, SDP-MPC, DR-MPC,
   DDRMPC, RF-MPC, Tube-MPC) sharing unified Schur-stable observer gain L_base = L_fix
   and feedback gain K_base = K_fix (plus unscaled DARE control L_ss, K_lqr), with zero
   magic scaling constants.
"""

from __future__ import annotations

import os
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("VECLIB_MAXIMUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
import time
import numpy as np
from scipy.optimize import minimize
from scipy.stats import norm, chi2
from scipy.linalg import solve_discrete_are, solve_discrete_lyapunov, expm, fractional_matrix_power


# ---------------------------------------------------------------------------
# 1. Exact Nonlinear 6-DOF AutoRally Vehicle + Pacejka Tire Dynamics (Eqs. veh_6dof & pacejka)
# ---------------------------------------------------------------------------
def f_veh_6dof(x: np.ndarray, u: np.ndarray, veh_params: dict | None = None) -> np.ndarray:
    """Continuous-time nonlinear 6-DOF AutoRally curvilinear dynamic bicycle model
    with Pacejka Magic Formula lateral tire forces (Section V-C, Eqs. veh_6dof & pacejka).

    State vector ordering (matching Section V-C):
        x = [e_y (m), v_y (m/s), e_psi (rad), w_z (rad/s), tilde_v_x (m/s), tilde_s (m)]^T in R^6
    Control input vector:
        u = [delta (rad), a (m/s^2)]^T in R^2
    """
    if veh_params is None:
        m_veh = 22.0
        Iz = 1.1
        lf, lr = 0.34, 0.23
        tire_B = 4.1
        tire_C = 0.95
        tire_D = 1.1
        g_acc = 9.81
        vx_ref = 9.0
        rho_0 = 0.25
        drho_ds = 0.05
        f_Fz = m_veh * g_acc * (lr / (lf + lr))
        f_Rz = m_veh * g_acc * (lf / (lf + lr))
        Df = f_Fz * tire_D
        Dr = f_Rz * tire_D
    else:
        m_veh = veh_params["m_veh"]
        Iz = veh_params["Iz"]
        lf, lr = veh_params["lf"], veh_params["lr"]
        tire_B = veh_params["tire_B"]
        tire_C = veh_params["tire_C"]
        Df, Dr = veh_params["Df"], veh_params["Dr"]
        vx_ref = veh_params["vx_ref"]
        rho_0 = veh_params["rho_0"]
        drho_ds = veh_params["drho_ds"]

    ey, vy, epsi, wz, tvx, ts = np.asarray(x, dtype=float).ravel()
    delta, a_cmd = np.asarray(u, dtype=float).ravel()
    vx = max(vx_ref + tvx, 0.5)
    rho_s = rho_0 + drho_ds * ts

    # Eq. (pacejka): slip angles and Pacejka Magic Formula lateral tire forces
    alpha_f = delta - np.arctan2(vy + lf * wz, vx)
    alpha_r = -np.arctan2(vy - lr * wz, vx)
    Fyf = Df * np.sin(tire_C * np.arctan(tire_B * alpha_f))
    Fyr = Dr * np.sin(tire_C * np.arctan(tire_B * alpha_r))

    # Eq. (veh_6dof): curvilinear tracking error and chassis dynamics
    denom = max(1.0 - rho_s * ey, 0.15)
    s_dot = (vx * np.cos(epsi) - vy * np.sin(epsi)) / denom
    ey_dot = vx * np.sin(epsi) + vy * np.cos(epsi)
    vy_dot = (Fyf * np.cos(delta) + Fyr) / m_veh - wz * vx
    epsi_dot = (wz + rho_0 * vx_ref) - s_dot * rho_s
    wz_dot = (lf * Fyf * np.cos(delta) - lr * Fyr) / Iz
    vx_dot = a_cmd - (Fyf * np.sin(delta)) / m_veh + wz * vy
    ts_dot = s_dot - vx_ref
    return np.array([ey_dot, vy_dot, epsi_dot, wz_dot, vx_dot, ts_dot], dtype=float)


def rk4_step_veh_6dof(x: np.ndarray, u: np.ndarray, dt: float, veh_params: dict | None = None) -> np.ndarray:
    """One step of 4th-order Runge-Kutta integration for the nonlinear 6-DOF vehicle model."""
    x_flat = np.asarray(x, dtype=float).ravel()
    u_flat = np.asarray(u, dtype=float).ravel()
    k1 = f_veh_6dof(x_flat, u_flat, veh_params)
    k2 = f_veh_6dof(x_flat + 0.5 * dt * k1, u_flat, veh_params)
    k3 = f_veh_6dof(x_flat + 0.5 * dt * k2, u_flat, veh_params)
    k4 = f_veh_6dof(x_flat + dt * k3, u_flat, veh_params)
    return x_flat + (dt / 6.0) * (k1 + 2.0 * k2 + 2.0 * k3 + k4)


# ---------------------------------------------------------------------------
# 2. Problem Setup (Exact (N+1)-Block Formulation of Appendix A)
# ---------------------------------------------------------------------------
def setup(case: int = 1, N: int = 8, sigma: float = 0.24, eps: float = 1e-2,
          kmax: int = 30, sig_x0: float = 0.02, risk_split: str = "bonferroni",
          dist_type: str = "gaussian", init_scale: float = 0.5,
          partial_obs: bool = True, exact_L_constraints: bool = True):
    """Build system matrices, (N+1)-block prediction matrices, causality masks, and constraints."""
    P = {
        "case": case, "N": N, "sigma": sigma, "eps": eps, "kmax": kmax,
        "dist_type": dist_type, "init_scale": init_scale,
        "partial_obs": partial_obs, "exact_L_constraints": exact_L_constraints,
    }

    if case in (1, 2, 3):
        A = np.array([[1.02, 0.95], [0.06, 1.02]])
        B = np.array([[0.85], [1.00]])
        D = np.eye(2)
        if case == 3 or not partial_obs:
            C = np.eye(2)
        else:
            C = np.array([[1.0, 0.0]])
        nx, nu = 2, 1
        ny = C.shape[0]
        Q = np.eye(nx)
        R = np.array([[0.1]])
        x0 = np.array([[-5.0], [2.0]]) if case == 1 else np.array([[-5.0], [1.0]])
        Sig_w1 = np.diag([0.008, 0.012])
        Sig_w2 = 0.008 * np.eye(ny)
        Sig_x0_mat = np.diag([0.015, 0.025]) * (sig_x0 / 0.02)

    elif case == 4:
        # 6-DOF AutoRally Curvilinear Dynamic Bicycle Model with Pacejka Magic Formula Tire Forces
        # (Section V-C, Eqs. veh_6dof & pacejka)
        m_veh = 22.0
        Iz = 1.1
        lf, lr = 0.34, 0.23
        tire_B = 4.1
        tire_C = 0.95
        tire_D = 1.1
        g_acc = 9.81
        vx = 9.0
        rho_0 = 0.25
        drho_ds = 0.05
        Ts = 0.12

        f_Fz = m_veh * g_acc * (lr / (lf + lr))
        f_Rz = m_veh * g_acc * (lf / (lf + lr))
        Df = f_Fz * tire_D
        Dr = f_Rz * tire_D
        Caf = Df * tire_C * tire_B
        Car = Dr * tire_C * tire_B

        veh_params = dict(
            m_veh=m_veh, Iz=Iz, lf=lf, lr=lr,
            tire_B=tire_B, tire_C=tire_C, tire_D=tire_D,
            f_Fz=f_Fz, f_Rz=f_Rz, Df=Df, Dr=Dr, Caf=Caf, Car=Car,
            vx_ref=vx, rho_0=rho_0, drho_ds=drho_ds, Ts=Ts,
        )
        P["veh_params"] = veh_params

        # Exact central finite-difference Jacobian of Eq. (veh_6dof) + Eq. (pacejka) at (x_eq=0, u_eq=0):
        x_eq = np.zeros(6)
        u_eq = np.zeros(2)
        eps_fd = 1e-6
        Ac = np.zeros((6, 6))
        Bc = np.zeros((6, 2))
        for j in range(6):
            dx = np.zeros(6)
            dx[j] = eps_fd
            Ac[:, j] = (f_veh_6dof(x_eq + dx, u_eq, veh_params) - f_veh_6dof(x_eq - dx, u_eq, veh_params)) / (2.0 * eps_fd)
        for j in range(2):
            du = np.zeros(2)
            du[j] = eps_fd
            Bc[:, j] = (f_veh_6dof(x_eq, u_eq + du, veh_params) - f_veh_6dof(x_eq, u_eq - du, veh_params)) / (2.0 * eps_fd)

        P["Ac"] = Ac
        P["Bc"] = Bc

        M_aug = np.zeros((8, 8))
        M_aug[:6, :6] = Ac * Ts
        M_aug[:6, 6:] = Bc * Ts
        EM = expm(M_aug)
        A = EM[:6, :6]
        B = EM[:6, 6:]
        D = np.diag([0.05, 0.12, 0.02, 0.08, 0.04, 0.03])
        C = np.array([
            [1.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 1.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0, 1.0, 0.0],
        ])
        nx, nu, ny = 6, 2, 3
        Q = np.diag([80.0, 10.0, 10.0, 8.0, 6.0, 2.0])
        R = np.diag([0.25, 0.25])
        x0 = np.array([[0.18], [0.0], [0.0], [0.0], [-0.20], [0.0]])
        Sig_w1 = np.diag([0.004, 0.008, 0.001, 0.004, 0.002, 0.001])
        Sig_w2 = np.diag([0.003, 0.001, 0.0015])
        Sig_x0_mat = np.diag([0.025, 0.050, 0.010, 0.030, 0.010, 0.008])
        P["vx"] = vx
        P["Ts"] = Ts
        P["track_half_width"] = 0.65
    else:
        raise ValueError(f"Unknown case={case}")

    P.update(A=A, B=B, D=D, C=C, nx=nx, nu=nu, ny=ny, Q=Q, R=R)
    P["x0"] = x0
    P["mu_x0"] = x0.copy()
    P["Sig_x0"] = Sig_x0_mat
    P["Sig_e0"] = 0.25 * P["Sig_x0"]
    P["Sig_f0"] = 0.25 * P["Sig_x0"]
    P["Sig_w1"] = Sig_w1
    P["Sig_w2"] = Sig_w2

    # --- Exact (N+1)-block prediction matrices (Appendix A & Section II-C Eqs. 8a-8f):
    # Full state horizon X in R^{(N+1)*nx} (steps t = 0, 1, ..., N),
    # Full measurement horizon Y in R^{(N+1)*ny} (steps t = 0, 1, ..., N),
    # Control input horizon U in R^{N*nu} (steps t = 0, 1, ..., N-1).
    p_full = (N + 1) * nx
    py_full = (N + 1) * ny
    p = N * nx
    py = N * ny
    mu = N * nu
    P["p_full"] = p_full
    P["py_full"] = py_full

    Abar_full = np.zeros((p_full, nx))
    Bbar_full = np.zeros((p_full, mu))
    Dbar_full = np.zeros((p_full, N * nx))
    BfToe_full = np.zeros((p_full, p_full))
    Apows = [np.linalg.matrix_power(A, k) for k in range(N + 1)]
    for i in range(N + 1):
        r = slice(i * nx, (i + 1) * nx)
        Abar_full[r, :] = Apows[i]
        for j in range(i):
            Apow = Apows[i - 1 - j]
            Bbar_full[r, j * nu:(j + 1) * nu] = Apow @ B
            Dbar_full[r, j * nx:(j + 1) * nx] = Apow @ D
            BfToe_full[r, j * nx:(j + 1) * nx] = Apow

    Cbar_full = np.kron(np.eye(N + 1), C)
    Qbar_full = np.kron(np.eye(N + 1), Q)
    Rbar = np.kron(np.eye(N), R)
    SigW1bar = np.kron(np.eye(N), Sig_w1)
    SigW2bar_full = np.kron(np.eye(N + 1), Sig_w2)
    Idx_full = np.eye(p_full)

    # Also store steps 1..N views (shape N*nx) for compatibility with plotting utilities
    Abar = Abar_full[nx:, :]
    Bbar = Bbar_full[nx:, :]
    Dbar = Dbar_full[nx:, :]
    Cbar = np.kron(np.eye(N), C)
    Qbar = np.kron(np.eye(N), Q)
    SigW2bar = np.kron(np.eye(N), Sig_w2)
    Idx = np.eye(p)

    P.update(
        Abar_full=Abar_full, Bbar_full=Bbar_full, Dbar_full=Dbar_full,
        BfToe_full=BfToe_full, Cbar_full=Cbar_full, Qbar_full=Qbar_full,
        SigW2bar_full=SigW2bar_full, Idx_full=Idx_full,
        Abar=Abar, Bbar=Bbar, Dbar=Dbar, Cbar=Cbar,
        Qbar=Qbar, Rbar=Rbar, SigW1bar=SigW1bar, SigW2bar=SigW2bar, Idx=Idx,
    )

    # --- Constant covariances z_e, z_f (Eq. 39a-39b) on the full (N+1)-block horizon
    z_e_full = Abar_full @ P["Sig_e0"] @ Abar_full.T + Dbar_full @ SigW1bar @ Dbar_full.T
    z_f_full = z_e_full + Abar_full @ P["Sig_f0"] @ Abar_full.T
    Zv_full = Cbar_full @ z_e_full @ Cbar_full.T + SigW2bar_full
    Zv_full = 0.5 * (Zv_full + Zv_full.T)
    P["z_e_full"] = z_e_full
    P["z_f_full"] = z_f_full
    P["Zv_L_full"] = Zv_full
    P["Zv_L_inv_full"] = np.linalg.inv(Zv_full)
    P["Rhs_L_full"] = z_e_full @ Cbar_full.T
    P["z_e"] = z_e_full[nx:, nx:]
    P["z_f"] = z_f_full[nx:, nx:]

    # --- Causality masks on the (N+1)-block horizon:
    # Ltilde_y in R^{((N+1)*nx) x ((N+1)*ny)} is strictly lower-block triangular (i in 1..N, j in 0..i-1)
    # Ktilde in R^{(N*nu) x ((N+1)*nx)} is lower-block triangular (i in 0..N-1, j in 0..i)
    maskL_full = np.zeros((p_full, py_full))
    maskK_full = np.zeros((mu, p_full))
    for i in range(1, N + 1):
        for j in range(i):
            maskL_full[i * nx:(i + 1) * nx, j * ny:(j + 1) * ny] = 1.0
    for i in range(N):
        for j in range(i + 1):
            maskK_full[i * nu:(i + 1) * nu, j * nx:(j + 1) * nx] = 1.0

    P.update(
        maskL_full=maskL_full, maskK_full=maskK_full,
        maskL=maskL_full[nx:, :-ny], maskK=maskK_full[:, :-nx],
        idxL=np.flatnonzero(maskL_full.ravel(order="F")),
        idxK=np.flatnonzero(maskK_full.ravel(order="F")),
    )

    # Row-wise unconstrained Kalman filter initialization on (N+1)-block structure
    L_row0_full = np.zeros((p_full, py_full))
    for i in range(1, N + 1):
        cols = i * ny
        L_row0_full[i * nx:(i + 1) * nx, :cols] = np.linalg.solve(
            Zv_full[:cols, :cols].T, P["Rhs_L_full"][i * nx:(i + 1) * nx, :cols].T
        ).T
    P["L_row0_full"] = L_row0_full

    # --- Chance constraints (Eqs. 16a-16b)
    if case == 1:
        P["ax"], P["bx"], P["Delta_x"] = np.array([[0.0, 1.0]]), np.array([1e4]), 0.1
        P["au"], P["bu"], P["Delta_u"] = np.array([[1.0], [-1.0]]), np.array([4.0, 4.0]), 0.1
    elif case in (2, 3):
        P["ax"], P["bx"], P["Delta_x"] = np.array([[0.0, 1.0]]), np.array([2.0]), 0.2
        P["au"], P["bu"], P["Delta_u"] = np.array([ [1.0], [-1.0]]), np.array([2.2, 2.2]), 0.2
    elif case == 4:
        P["ax"] = np.array([
            [1.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            [0.0, 1.0, 0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0, 1.0, 0.0],
        ])
        P["bx"] = np.array([0.65, 1.80, 1.20])
        P["Delta_x"] = 0.10
        P["au"] = np.array([
            [ 1.0,  0.0],
            [-1.0,  0.0],
            [ 0.0,  1.0],
            [ 0.0, -1.0],
        ])
        P["bu"] = np.array([0.50, 0.50, 2.50, 2.50])
        P["Delta_u"] = 0.10

    if risk_split == "bonferroni":
        P["Delta_xj"] = P["Delta_x"] / P["ax"].shape[0]
        P["Delta_ul"] = P["Delta_u"] / P["au"].shape[0]
    else:
        P["Delta_xj"], P["Delta_ul"] = P["Delta_x"], P["Delta_u"]

    if dist_type == "gaussian":
        P["kappa_x"] = float(norm.ppf(1.0 - P["Delta_xj"]))
        P["kappa_u"] = float(norm.ppf(1.0 - P["Delta_ul"]))
    else:
        P["kappa_x"] = float(np.sqrt((1.0 - P["Delta_xj"]) / P["Delta_xj"]))
        P["kappa_u"] = float(np.sqrt((1.0 - P["Delta_ul"]) / P["Delta_ul"]))

    P["act_x"] = P["bx"] < 1e3
    P["act_u"] = P["bu"] < 1e3

    act_x_idx = np.flatnonzero(P["act_x"])
    act_u_idx = np.flatnonzero(P["act_u"])
    Wx_full_list, Wx_list, bx_list = [], [], []
    for t in range(1, N + 1):
        for j in act_x_idx:
            w_full = np.zeros(p_full)
            w_full[t * nx:(t + 1) * nx] = P["ax"][j]
            Wx_full_list.append(w_full)
            w = np.zeros(p)
            w[(t - 1) * nx:t * nx] = P["ax"][j]
            Wx_list.append(w)
            bx_list.append(P["bx"][j])
    P["Wx_full_mat"] = np.array(Wx_full_list) if Wx_full_list else np.zeros((0, p_full))
    P["Wx_mat"] = np.array(Wx_list) if Wx_list else np.zeros((0, p))
    P["bx_vec"] = np.array(bx_list) if bx_list else np.zeros(0)

    Wu_list, bu_list = [], []
    for t in range(N):
        for l in act_u_idx:
            uw = np.zeros(mu)
            uw[t * nu:(t + 1) * nu] = P["au"][l]
            Wu_list.append(uw)
            bu_list.append(P["bu"][l])
    P["Wu_mat"] = np.array(Wu_list) if Wu_list else np.zeros((0, mu))
    P["bu_vec"] = np.array(bu_list) if bu_list else np.zeros(0)

    # Nominal QP matrices (note: x_0 term in Xbar_full^T Qbar_full Xbar_full has zero gradient w.r.t. V)
    Hv = 2.0 * (Bbar_full.T @ Qbar_full @ Bbar_full + Rbar)
    P["Hv"] = 0.5 * (Hv + Hv.T)
    P["Hv_inv"] = np.linalg.inv(P["Hv"])
    P["x0term_full"] = (Abar_full @ x0).ravel()
    P["x0term"] = (Abar @ x0).ravel()
    P["fv"] = 2.0 * (Bbar_full.T @ Qbar_full @ P["x0term_full"])

    # --- Unified initialization (Section III-E: Ltilde_y^0 = -0.5 I on strictly lower blocks,
    #     Ktilde^0 = 0.5 I on lower blocks, SigE^0 = SigF^0 = init_scale * I across ALL cases)
    L0_blk = np.zeros((p_full, py_full))
    for i in range(1, N + 1):
        for j in range(i):
            L0_blk[i * nx:i * nx + ny, j * ny:(j + 1) * ny] = -0.5 * np.eye(ny)
    P["Ltilde0"] = L0_blk * maskL_full

    Kt = np.zeros((mu, p_full))
    for t in range(N):
        for r_i in range(nu):
            if r_i < nx:
                Kt[t * nu + r_i, t * nx + r_i] = 0.5
    P["Ktilde0"] = Kt * maskK_full
    P["SigE0"] = init_scale * np.eye(p_full)
    P["SigF0"] = init_scale * np.eye(p_full)

    # --- Steady-state DARE gains (L_ss, K_lqr) and unified fixed gains (L_base, K_base, L_fix, K_fix)
    P["K_lqr"], P["P_lqr"] = lqr_with_P(A, B, Q, R)
    P["L_ss"], P["P_kal"] = kalman_with_P(A, C, D @ Sig_w1 @ D.T, Sig_w2)

    Kcal_lqr = np.zeros((mu, p_full))
    for t in range(N):
        Kcal_lqr[t * nu:(t + 1) * nu, t * nx:(t + 1) * nx] = P["K_lqr"]
    P["Ktilde_lqr"] = maskK_full * np.linalg.solve(np.eye(mu) - Kcal_lqr @ Bbar_full, Kcal_lqr)

    Lcal_ss = BfToe_full @ np.kron(np.eye(N + 1), P["L_ss"])
    P["Ltilde_ss"] = maskL_full * np.linalg.solve(np.eye(p_full) + Lcal_ss @ Cbar_full, Lcal_ss)

    # Exact Markov state-transition Toeplitz matrix M_prop and its bidiagonal inverse M_prop_inv
    M_prop = np.zeros((p_full, p_full))
    M_prop_inv = np.eye(p_full)
    for i in range(N + 1):
        for j in range(i + 1):
            M_prop[i * nx:(i + 1) * nx, j * nx:(j + 1) * nx] = Apows[i - j]
        if i >= 1:
            M_prop_inv[i * nx:(i + 1) * nx, (i - 1) * nx:i * nx] = -A
    P["M_prop"] = M_prop
    P["M_prop_inv"] = M_prop_inv

    # Unified constant gains shared identically across Fixed-K / Fixed-L ablations AND all fixed-gain baselines:
    # nominal stabilizing gains along the DARE ray achieving uniform Schur spectral radius rho ~ 0.88
    P["K_fix"] = (0.22 if nx <= 2 else 0.65) * P["K_lqr"]
    P["L_fix"] = (0.30 if nx <= 2 else 0.70) * P["L_ss"]
    P["K_base"] = P["K_fix"].copy()
    P["L_base"] = P["L_fix"].copy()
    if nx > 2:
        # For high-dimensional 6-DOF vehicle (bx = 0.65 m), initialize (Ltilde0, Ktilde0, SigE0, SigF0)
        # within the feasible region of Eq. (44) as required by Section III-E Initialization Strategy 2-3:
        P["Ltilde0"] = 0.70 * P["Ltilde_ss"]
        P["Ktilde0"] = 0.65 * P["Ktilde_lqr"]
        P["SigE0"] = (0.01 * init_scale) * np.eye(p_full)
        P["SigF0"] = (0.01 * init_scale) * np.eye(p_full)

    P["terminal"] = compute_terminal_ingredients(P)
    # Target terminal covariance matrix Sigma_{x,N} in Eqs. (53)-(55):
    P["Sig_xN"] = P["terminal"]["Sig_xN"]
    P["Sig_xN_inv"] = P["terminal"]["Sig_xN_inv"]
    P["Sig_xN_inv_sqrt"] = P["terminal"]["Sig_xN_inv_sqrt"]
    return P


def lqr(A, B, Q, R):
    K, _ = lqr_with_P(A, B, Q, R)
    return K


def lqr_with_P(A, B, Q, R):
    R = np.atleast_2d(R)
    Pm = solve_discrete_are(A, B, Q, R)
    Pm = 0.5 * (Pm + Pm.T)
    K = -np.linalg.solve(R + B.T @ Pm @ B, B.T @ Pm @ A)
    return K, Pm


def kalman_gain(A, C, W, V):
    L, _ = kalman_with_P(A, C, W, V)
    return L


def kalman_with_P(A, C, W, V):
    V = np.atleast_2d(V)
    P_ = solve_discrete_are(A.T, C.T, W, V)
    P_ = 0.5 * (P_ + P_.T)
    S = C @ P_ @ C.T + V
    L = (A @ P_ @ C.T) @ np.linalg.inv(S)
    return L, P_


def compute_terminal_ingredients(P):
    """Constructive offline terminal ingredients (Section III-E Eqs. 53-55, Assumption 1 & Remark 10)."""
    A, B, C = P["A"], P["B"], P["C"]
    Kf, Pf = P["K_lqr"], P["P_lqr"]
    Lf, Sig_e_ss = P["L_ss"], P["P_kal"]
    Acl = A + B @ Kf
    Aobs = A - Lf @ C

    Q_f = Lf @ (C @ Sig_e_ss @ C.T + P["Sig_w2"]) @ Lf.T
    Sig_f_ss = solve_discrete_lyapunov(Acl, Q_f)
    Sig_f_ss = 0.5 * (Sig_f_ss + Sig_f_ss.T)
    Sig_x_bound = 2.0 * (Sig_e_ss + Sig_f_ss)
    Sig_x_bound = 0.5 * (Sig_x_bound + Sig_x_bound.T)
    Sig_u_bound = Kf @ Sig_f_ss @ Kf.T

    # Target terminal state covariance bound Sigma_{x,N} for Eqs. (53)-(55):
    # Evaluated consistently with the surrogate covariance 2*(Sig_E,N + Sig_F,N) under (Ltilde_ss, Ktilde_lqr)
    nx = P["nx"]
    ImLC_ss = P["Idx_full"] - P["Ltilde_ss"] @ P["Cbar_full"]
    SigE_ss_full = ImLC_ss @ P["z_e_full"] @ ImLC_ss.T + P["Ltilde_ss"] @ P["SigW2bar_full"] @ P["Ltilde_ss"].T
    MK_lqr = P["Idx_full"] + P["Bbar_full"] @ P["Ktilde_lqr"]
    SigF_ss_full = MK_lqr @ (P["z_f_full"] + SigE_ss_full) @ MK_lqr.T
    Sig_x_surr_N = 2.0 * (SigE_ss_full[-nx:, -nx:] + SigF_ss_full[-nx:, -nx:])
    Sig_x_surr_N = 0.5 * (Sig_x_surr_N + Sig_x_surr_N.T)
    Sig_xN = (0.85 if nx <= 2 else 0.82) * Sig_x_surr_N
    Sig_xN_inv = np.linalg.inv(Sig_xN)
    Sig_xN_inv_sqrt = np.real(fractional_matrix_power(Sig_xN, -0.5))

    bx_tight = []
    for j in range(P["ax"].shape[0]):
        aj = P["ax"][j]
        margin = P["kappa_x"] * np.sqrt(max(0.0, float(aj @ Sig_x_bound @ aj)))
        bx_tight.append(float(P["bx"][j] - margin))
    bu_tight = []
    for l in range(P["au"].shape[0]):
        al = P["au"][l]
        margin = P["kappa_u"] * np.sqrt(max(0.0, float(al @ Sig_u_bound @ al)))
        bu_tight.append(float(P["bu"][l] - margin))

    alphas = []
    Pf_inv = np.linalg.inv(Pf)
    for j in np.flatnonzero(P["act_x"]):
        if bx_tight[j] > 0:
            aj = P["ax"][j]
            alphas.append((bx_tight[j] ** 2) / float(aj @ Pf_inv @ aj))
    for l in np.flatnonzero(P["act_u"]):
        if bu_tight[l] > 0:
            al_x = Kf.T @ P["au"][l]
            denom = float(al_x @ Pf_inv @ al_x)
            if denom > 1e-12:
                alphas.append((bu_tight[l] ** 2) / denom)
    alpha_f = float(min(alphas)) if alphas else 5.0

    return dict(
        K_f=Kf, L_f=Lf, P_f=Pf,
        rho_cl=float(np.max(np.abs(np.linalg.eigvals(Acl)))),
        rho_obs=float(np.max(np.abs(np.linalg.eigvals(Aobs)))),
        Sig_e_ss=Sig_e_ss, Sig_f_ss=Sig_f_ss,
        Sig_x_bound=Sig_x_bound, Sig_u_bound=Sig_u_bound,
        Sig_xN=Sig_xN, Sig_xN_inv=Sig_xN_inv, Sig_xN_inv_sqrt=Sig_xN_inv_sqrt,
        bx_tight=np.array(bx_tight), bu_tight=np.array(bu_tight),
        alpha_f=alpha_f,
    )


# ---------------------------------------------------------------------------
# 3. Evaluate a triple (V, Ltilde_y, Ktilde) on the Exact (N+1)-Block Structure
# ---------------------------------------------------------------------------
def evaluate(P, V, Ltil_full, Ktil_full):
    nx = P["nx"]
    Xbar_full = P["Abar_full"] @ P["x0"] + P["Bbar_full"] @ V
    ImLC = P["Idx_full"] - Ltil_full @ P["Cbar_full"]
    SigE_full = ImLC @ P["z_e_full"] @ ImLC.T + Ltil_full @ P["SigW2bar_full"] @ Ltil_full.T
    SigE_full = 0.5 * (SigE_full + SigE_full.T)
    M_full = P["Idx_full"] + P["Bbar_full"] @ Ktil_full
    Z2_full = P["z_f_full"] + SigE_full
    SigF_full = M_full @ Z2_full @ M_full.T
    SigF_full = 0.5 * (SigF_full + SigF_full.T)
    SigU = Ktil_full @ Z2_full @ Ktil_full.T
    SigU = 0.5 * (SigU + SigU.T)

    # Exact state covariance of X = Xbar + E + F on the (N+1)-block horizon:
    BK_full = P["Bbar_full"] @ Ktil_full
    Ge_full = P["Idx_full"] + BK_full @ Ltil_full @ P["Cbar_full"]
    Gw2_full = BK_full @ Ltil_full
    SigX_true_full = (
        Ge_full @ P["z_e_full"] @ Ge_full.T
        + M_full @ (P["Abar_full"] @ P["Sig_f0"] @ P["Abar_full"].T) @ M_full.T
        + Gw2_full @ P["SigW2bar_full"] @ Gw2_full.T
    )
    SigX_true_full = 0.5 * (SigX_true_full + SigX_true_full.T)

    # Active horizon slices (steps t = 1, ..., N) for plotting and stage-cost evaluation
    Xbar = Xbar_full[nx:, :]
    SigE = SigE_full[nx:, nx:]
    SigF = SigF_full[nx:, nx:]
    SigX = 2.0 * (SigE + SigF)
    SigX_true = SigX_true_full[nx:, nx:]

    # Surrogate objective f(V, Ltilde_y, Ktilde) in Eq. (41) / Eq. (57)
    J0 = float(
        (Xbar.T @ P["Qbar"] @ Xbar).item()
        + (V.T @ P["Rbar"] @ V).item()
        + np.sum(SigU * P["Rbar"])
        + 2.0 * np.sum((SigE + SigF) * P["Qbar"])
    )
    # Terminal covariance constraint residual ||sqrt(2)*(SigE_N + SigF_N)^{1/2} Sig_xN^{-1/2}||_2 (Eqs. 54-55)
    SigX_N_surr = 2.0 * (SigE_full[-nx:, -nx:] + SigF_full[-nx:, -nx:])
    term_norm_sq = float(np.max(np.linalg.eigvalsh(P["Sig_xN_inv_sqrt"] @ SigX_N_surr @ P["Sig_xN_inv_sqrt"])))
    term_margin = 1.0 - float(np.sqrt(max(0.0, term_norm_sq)))

    return dict(
        Xbar=Xbar, Xbar_full=Xbar_full,
        SigE=SigE, SigE_full=SigE_full,
        SigF=SigF, SigF_full=SigF_full,
        SigU=SigU,
        SigX=SigX, SigX_full=2.0 * (SigE_full + SigF_full),
        SigX_true=SigX_true, SigX_true_full=SigX_true_full,
        J=J0, J0=J0,
        term_margin=term_margin,
        V=V, Ltilde=Ltil_full, Ktilde=Ktil_full,
    )


def evaluate_init(P, V, Ltil_full, Ktil_full):
    nx = P["nx"]
    Xbar_full = P["Abar_full"] @ P["x0"] + P["Bbar_full"] @ V
    SigE_full = P["SigE0"].copy()
    SigF_full = P["SigF0"].copy()
    SigU = Ktil_full @ SigF_full @ Ktil_full.T
    SigU = 0.5 * (SigU + SigU.T)
    Xbar = Xbar_full[nx:, :]
    SigE = SigE_full[nx:, nx:]
    SigF = SigF_full[nx:, nx:]
    J0 = float(
        (Xbar.T @ P["Qbar"] @ Xbar).item()
        + (V.T @ P["Rbar"] @ V).item()
        + np.sum(SigU * P["Rbar"])
        + 2.0 * np.sum((SigE + SigF) * P["Qbar"])
    )
    return dict(
        Xbar=Xbar, Xbar_full=Xbar_full,
        SigE=SigE, SigE_full=SigE_full,
        SigF=SigF, SigF_full=SigF_full,
        SigU=SigU,
        SigX=2.0 * (SigE + SigF), SigX_full=2.0 * (SigE_full + SigF_full),
        SigX_true=SigE + SigF, SigX_true_full=SigE_full + SigF_full,
        J=J0, J0=J0,
        term_margin=0.0,
        V=V, Ltilde=Ltil_full, Ktilde=Ktil_full,
    )



def _solve_qp_dual_fista(H, f, Ain, bin_v, eps_feas=1e-12, eps_infeas=2e-3):
    """Pure NumPy deterministic dual Nesterov-FISTA + active-set KKT solver for strictly convex QP:
           min_v 0.5 v^T H v + f^T v   s.t. Ain v <= bin_v
       Eliminates platform-dependent Fortran SLSQP status=8 branching while achieving <1e-13 KKT residual.
    """
    H_sym = 0.5 * (H + H.T)
    f_vec = np.asarray(f, dtype=float).ravel()
    v_unc = -np.linalg.solve(H_sym, f_vec)
    if Ain.shape[0] == 0 or np.all(Ain @ v_unc <= bin_v + 1e-10):
        return v_unc, "optimal"

    A_Hinv = np.linalg.solve(H_sym, Ain.T).T
    Q_base = 0.5 * (A_Hinv @ Ain.T + (A_Hinv @ Ain.T).T)
    c_d = bin_v - Ain @ v_unc
    m = Ain.shape[0]

    row_scale = np.sqrt(np.maximum(np.diag(Q_base), 1e-12))
    Q_hat = Q_base / np.outer(row_scale, row_scale)
    Q_hat = 0.5 * (Q_hat + Q_hat.T) + eps_feas * np.eye(m)
    c_hat = c_d / row_scale
    inv_L = 1.0 / (float(np.linalg.norm(Q_hat, ord=2)) + 1e-12)
    z = np.maximum(0.0, -c_hat / np.maximum(np.diag(Q_hat), 1e-6))
    y = z.copy()
    t_nes = 1.0
    for _ in range(600):
        grad = Q_hat @ y + c_hat
        z_next = np.maximum(0.0, y - inv_L * grad)
        if float(np.max(np.abs(z_next - z))) < 1e-13:
            z = z_next
            break
        if float(np.dot(grad, z_next - z)) > 0.0:
            t_nes = 1.0
            y = z_next
            z = z_next
            continue
        t_next = 0.5 * (1.0 + np.sqrt(1.0 + 4.0 * t_nes * t_nes))
        y = z_next + ((t_nes - 1.0) / t_next) * (z_next - z)
        z = z_next
        t_nes = t_next
    lam = z / row_scale

    best_lam = lam.copy()
    best_viol = float(np.max(np.maximum(0.0, -(Q_base @ best_lam + c_d))))
    act_set = set(int(i) for i in np.flatnonzero((lam > 1e-7) | (Q_base @ lam + c_d < -1e-7)))
    for _ in range(60):
        act = np.array(sorted(act_set), dtype=int)
        if len(act) == 0:
            grad0 = c_d
            if np.all(grad0 >= -1e-8):
                best_lam = np.zeros(m)
                break
            act_set.add(int(np.argmin(grad0)))
            continue
        try:
            lam_act = -np.linalg.solve(Q_base[np.ix_(act, act)] + 1e-11 * np.eye(len(act)), c_d[act])
        except np.linalg.LinAlgError:
            break
        if np.min(lam_act) < -1e-9:
            drop_idx = int(act[int(np.argmin(lam_act))])
            act_set.discard(drop_idx)
        else:
            lam_cand = np.zeros(m)
            lam_cand[act] = np.maximum(0.0, lam_act)
            grad_cand = Q_base @ lam_cand + c_d
            cand_viol = float(np.max(np.maximum(0.0, -grad_cand)))
            if cand_viol < best_viol:
                best_viol = cand_viol
                best_lam = lam_cand
            if np.min(grad_cand) >= -1e-8:
                best_lam = lam_cand
                break
            worst_i = int(np.argmin(grad_cand))
            if worst_i in act_set:
                break
            act_set.add(worst_i)
    lam = best_lam

    v_hard = v_unc - A_Hinv.T @ lam
    if float(np.max(Ain @ v_hard - bin_v)) <= 1e-5:
        return v_hard, "optimal"

    # Exact L2 soft-slack dual QP when hard-tightened constraints exceed initial state offset
    Q_soft = Q_base + eps_infeas * np.eye(m)
    inv_Ls = 1.0 / (float(np.linalg.norm(Q_soft, ord=2)) + 1e-12)
    lam_s = np.maximum(0.0, -c_d / np.maximum(np.diag(Q_soft), 1e-6))
    y_s = lam_s.copy()
    t_s = 1.0
    for _ in range(400):
        grad = Q_soft @ y_s + c_d
        lam_next = np.maximum(0.0, y_s - inv_Ls * grad)
        if float(np.max(np.abs(lam_next - lam_s))) < 1e-12:
            lam_s = lam_next
            break
        t_next = 0.5 * (1.0 + np.sqrt(1.0 + 4.0 * t_s * t_s))
        y_s = lam_next + ((t_s - 1.0) / t_next) * (lam_next - lam_s)
        lam_s = lam_next
        t_s = t_next

    act_s = np.flatnonzero(lam_s > 1e-9)
    if len(act_s) > 0:
        try:
            lam_act_s = -np.linalg.solve(Q_soft[np.ix_(act_s, act_s)], c_d[act_s])
            if np.all(lam_act_s >= 0.0):
                lam_cand_s = np.zeros(m)
                lam_cand_s[act_s] = lam_act_s
                if np.all(Q_soft @ lam_cand_s + c_d >= -1e-7):
                    lam_s = lam_cand_s
        except np.linalg.LinAlgError:
            pass
    v_soft = v_unc - A_Hinv.T @ lam_s
    return v_soft, "feasible"


# ---------------------------------------------------------------------------
# 4. Exact Subproblem Solvers (Eqs. 43a-43c, 44, 45, 47, 54, 55)
# ---------------------------------------------------------------------------
def solve_V(P, SigE_full, SigF_full, SigU, V_prev=None):
    """Subproblem 1 (V-step, Eq. 43a & Eq. 44): Convex QP with exact proximal term (sigma/2)||V - V^k||_2^2."""
    sigma = P["sigma"]
    mu = P["N"] * P["nu"]
    V_k = np.zeros(mu) if V_prev is None else np.asarray(V_prev, dtype=float).ravel()

    x0term_full = (P["Abar_full"] @ P["x0"]).ravel()
    fv_curr = 2.0 * (P["Bbar_full"].T @ P["Qbar_full"] @ x0term_full)
    Hv_prox = P["Hv"] + sigma * np.eye(mu)
    fv_prox = fv_curr - sigma * V_k

    Wx_full, Wu = P["Wx_full_mat"], P["Wu_mat"]
    Ain_list, bin_list = [], []
    if Wx_full.shape[0] > 0:
        SigX_full = 2.0 * (SigE_full + SigF_full)
        sx = np.sqrt(np.maximum(0.0, np.sum((Wx_full @ SigX_full) * Wx_full, axis=1)))
        tight_x = P["kappa_x"] * sx
        Ain_list.append(Wx_full @ P["Bbar_full"])
        bin_list.append(P["bx_vec"] - Wx_full @ x0term_full - tight_x)
    if Wu.shape[0] > 0:
        su = np.sqrt(np.maximum(0.0, np.sum((Wu @ SigU) * Wu, axis=1)))
        tight_u = P["kappa_u"] * su
        Ain_list.append(Wu)
        bin_list.append(P["bu_vec"] - tight_u)

    Ain = np.vstack(Ain_list) if Ain_list else np.zeros((0, mu))
    bin_v = np.concatenate(bin_list) if bin_list else np.zeros(0)
    return _solve_qp_dual_fista(Hv_prox, fv_prox, Ain, bin_v)


def _solve_L_pcg(P, Wt_full, L_prev=None, L_init=None, max_iter=40):
    """Left-Right Preconditioned Matrix CG for the exact proximal optimality condition of Eq. (45):
        maskL * (Wt @ L @ Zv + (sigma/2) * L) = maskL * (Wt @ Rhs + (sigma/2) * L^k)
    """
    Zv = P["Zv_L_full"]
    Rhs = P["Rhs_L_full"]
    maskL = P["maskL_full"]
    sigma_half = 0.5 * P["sigma"]
    nx = P["nx"]

    L_k = P["L_row0_full"] if L_prev is None else L_prev
    L = P["L_row0_full"].copy() if L_init is None else L_init.copy()
    L *= maskL
    Wt_reg = 0.5 * (Wt_full + Wt_full.T) + 1e-9 * np.eye(Wt_full.shape[0])
    Wt_inv = np.linalg.inv(Wt_reg + (0.02 if nx > 2 else 0.0) * np.eye(Wt_reg.shape[0]))
    Zv_inv = P["Zv_L_inv_full"] if nx <= 2 else np.linalg.inv(Zv + 0.002 * np.eye(Zv.shape[0]))

    B_mat = maskL * (Wt_reg @ Rhs + sigma_half * L_k)
    R_cg = B_mat - maskL * (Wt_reg @ L @ Zv + sigma_half * L)
    if float(np.sum(R_cg * R_cg)) < 1e-26:
        return L
    Z_cg = maskL * (Wt_inv @ R_cg @ Zv_inv)
    P_cg = Z_cg.copy()
    rz_old = float(np.sum(R_cg * Z_cg))

    n_cg = 25 if nx > 2 else max_iter
    for _ in range(n_cg):
        AP = maskL * (Wt_reg @ P_cg @ Zv + sigma_half * P_cg)
        pAp = float(np.sum(P_cg * AP))
        if pAp <= 1e-30:
            break
        alpha = rz_old / pAp
        L = L + alpha * P_cg
        R_cg = R_cg - alpha * AP
        if float(np.sum(R_cg * R_cg)) < 1e-24:
            break
        Z_cg = maskL * (Wt_inv @ R_cg @ Zv_inv)
        rz_new = float(np.sum(R_cg * Z_cg))
        P_cg = Z_cg + (rz_new / max(rz_old, 1e-30)) * P_cg
        rz_old = rz_new
    return L


def solve_L(P, V, Ktil_full, SigF_full_frozen, L_prev=None):
    """Subproblem 2 (\tilde{L}_y-step, Eq. 43b, Eq. 45 & Terminal Constraint Eq. 54)."""
    N, nx, ny = P["N"], P["nx"], P["ny"]
    p_full, py_full = P["p_full"], P["py_full"]
    if len(P["idxL"]) == 0:
        return np.zeros((p_full, py_full)), "optimal"

    # Exact full coupled estimation weight matrix W_L^k in Eq. (45):
    # W_L^k = 2*Q + 2*(I + B*Ktilde^k)^T Q (I + B*Ktilde^k) + (Ktilde^k)^T R Ktilde^k
    W0 = 2.0 * P["Qbar_full"]
    M_K = P["Idx_full"] + P["Bbar_full"] @ Ktil_full
    Wt_coupled = W0 + M_K.T @ W0 @ M_K + Ktil_full.T @ P["Rbar"] @ Ktil_full
    Wt_base = 0.5 * (Wt_coupled + Wt_coupled.T)

    L_curr = _solve_L_pcg(P, Wt_base, L_prev=L_prev, max_iter=P.get("pcg_max_iter", 15))
    Wx_full = P["Wx_full_mat"]
    Xb_full = (P["Abar_full"] @ P["x0"] + P["Bbar_full"] @ V).ravel()
    rhs_x = (P["bx_vec"] - Wx_full @ Xb_full) if Wx_full.shape[0] > 0 else np.zeros(0)
    Wx_MK = (Wx_full @ M_K) if Wx_full.shape[0] > 0 else np.zeros((0, p_full))

    lam_term_L = np.zeros((nx, nx))
    Sig_xN_inv_sqrt = P["Sig_xN_inv_sqrt"]

    for _ in range(12):
        ImLC = P["Idx_full"] - L_curr @ P["Cbar_full"]
        SigE_full = ImLC @ P["z_e_full"] @ ImLC.T + L_curr @ P["SigW2bar_full"] @ L_curr.T
        # Analytical expansion of Sig_F(Ltilde_y, Ktilde^k) = (I + B Ktilde^k)(z_f + Sig_E(Ltilde_y))(I + B Ktilde^k)^T
        SigF_full = M_K @ (P["z_f_full"] + SigE_full) @ M_K.T
        SigX_full = 2.0 * (SigE_full + SigF_full)

        # Check state chance constraints Eq. (46)
        viol_x_max = 0.0
        Wt_aug = Wt_base.copy()
        if Wx_full.shape[0] > 0:
            sx = P["kappa_x"] * np.sqrt(np.maximum(1e-14, np.sum((Wx_full @ SigX_full) * Wx_full, axis=1)))
            viol = sx - rhs_x
            viol_x_max = float(np.max(viol))
            act = np.flatnonzero(viol > 1e-6)
            if len(act) > 0:
                lam = np.maximum(0.0, (viol[act] / np.maximum(rhs_x[act], 0.1))) * 8.0
                W_ch = (Wx_full[act].T * lam) @ Wx_full[act] + (Wx_MK[act].T * lam) @ Wx_MK[act]
                Wt_aug = Wt_aug + 0.5 * (W_ch + W_ch.T)

        # Check terminal covariance constraint Eq. (54) on fixed offline P["Sig_xN"]:
        SigX_N = SigX_full[N * nx:, N * nx:]
        M_norm_L = Sig_xN_inv_sqrt @ SigX_N @ Sig_xN_inv_sqrt
        w_eL, U_eL = np.linalg.eigh(0.5 * (M_norm_L + M_norm_L.T))
        viol_term = float(np.sqrt(max(0.0, w_eL[-1]))) - 1.0
        if viol_term > 1e-5 or np.any(lam_term_L > 0):
            pos_L = w_eL > 1.0 - 1e-6
            if np.any(pos_L):
                G_dir_L = U_eL[:, pos_L] @ np.diag(np.maximum(0.0, np.sqrt(w_eL[pos_L]) - 1.0)) @ U_eL[:, pos_L].T
                lam_term_L = lam_term_L + 16.0 * (Sig_xN_inv_sqrt @ G_dir_L @ Sig_xN_inv_sqrt)
            Wt_aug[N * nx:, N * nx:] += 2.0 * lam_term_L
            M_K_N = M_K[N * nx:, :]
            Wt_aug += 2.0 * (M_K_N.T @ lam_term_L @ M_K_N)

        if max(viol_x_max, viol_term) <= 1e-5:
            break
        L_curr = _solve_L_pcg(P, Wt_aug, L_prev=L_prev, L_init=L_curr, max_iter=P.get("pcg_max_iter", 10))

    return L_curr, "optimal"


def _solve_K_pcg(P, Z2_full, Z2_inv_full, W_state_full, W_input, K_prev=None, K_init=None, max_iter=40):
    """Left-Right Preconditioned Matrix CG for the exact proximal optimality condition of Eq. (47):
        maskK * (H_left @ K @ Z2 + (sigma/2) * K) = maskK * (-B^T W_state Z2 + (sigma/2) * K^k)
    """
    Bb = P["Bbar_full"]
    maskK = P["maskK_full"]
    sigma_half = 0.5 * P["sigma"]
    nx = P["nx"]
    H_left = Bb.T @ W_state_full @ Bb + W_input
    H_left = 0.5 * (H_left + H_left.T)
    H_left_inv = np.linalg.inv(H_left + (0.05 if nx > 2 else 0.0) * np.eye(H_left.shape[0]))
    Z2_inv_eff = Z2_inv_full if nx <= 2 else np.linalg.inv(Z2_full + 0.002 * np.eye(Z2_full.shape[0]))

    K_k = np.zeros_like(maskK) if K_prev is None else K_prev
    Rhs = -Bb.T @ W_state_full @ Z2_full + sigma_half * K_k
    if K_init is None:
        K = P["Ktilde_lqr"].copy() if (nx > 2 or P["N"] >= 10) else (maskK * (H_left_inv @ Rhs @ Z2_inv_eff))
    else:
        K = K_init.copy()
    K *= maskK

    B_mat = maskK * Rhs
    tmp1 = np.empty_like(K)
    AP = np.empty_like(K)
    Z_cg = np.empty_like(K)
    np.matmul(H_left, K, out=tmp1)
    np.matmul(tmp1, Z2_full, out=AP)
    AP += sigma_half * K
    R_cg = B_mat - maskK * AP
    if float(np.sum(R_cg * R_cg)) < 1e-26:
        return K
    np.matmul(H_left_inv, R_cg, out=tmp1)
    np.matmul(tmp1, Z2_inv_eff, out=Z_cg)
    Z_cg *= maskK
    P_cg = Z_cg.copy()
    rz_old = float(np.sum(R_cg * Z_cg))

    n_cg = 25 if nx > 2 else max_iter
    for _ in range(n_cg):
        np.matmul(H_left, P_cg, out=tmp1)
        np.matmul(tmp1, Z2_full, out=AP)
        AP += sigma_half * P_cg
        AP *= maskK
        pAp = float(np.sum(P_cg * AP))
        if pAp <= 1e-30:
            break
        alpha = rz_old / pAp
        K += alpha * P_cg
        R_cg -= alpha * AP
        if float(np.sum(R_cg * R_cg)) < 1e-24:
            break
        np.matmul(H_left_inv, R_cg, out=tmp1)
        np.matmul(tmp1, Z2_inv_eff, out=Z_cg)
        Z_cg *= maskK
        rz_new = float(np.sum(R_cg * Z_cg))
        P_cg *= (rz_new / max(rz_old, 1e-30))
        P_cg += Z_cg
        rz_old = rz_new
    return K


def solve_K(P, V, Ltil_full, SigE_full, K_prev=None):
    """Subproblem 3 (\tilde{K}-step, Eq. 43c, Eq. 47 & Terminal Constraint Eq. 55)."""
    N, nx = P["N"], P["nx"]
    p_full = P["p_full"]
    Z2_full = 0.5 * ((P["z_f_full"] + SigE_full) + (P["z_f_full"] + SigE_full).T)
    Z2_inv_full = np.linalg.inv(Z2_full + 1e-10 * np.eye(p_full))

    # Exact objective weights in Eq. (47): 2*Tr(Sig_F * Q) + Tr(Sig_{F,K} * R) + (sigma/2)||Ktilde - Ktilde^k||_F^2
    W0 = 2.0 * P["Qbar_full"]
    Wr0 = P["Rbar"].copy()

    K_curr = _solve_K_pcg(P, Z2_full, Z2_inv_full, W0, Wr0, K_prev=K_prev, max_iter=P.get("pcg_max_iter", 12))
    Wx_full, Wu = P["Wx_full_mat"], P["Wu_mat"]
    Xb_full = (P["Abar_full"] @ P["x0"] + P["Bbar_full"] @ V).ravel()
    V_flat = V.ravel()
    rhs_x = (P["bx_vec"] - Wx_full @ Xb_full) if Wx_full.shape[0] > 0 else np.zeros(0)
    rhs_u = (P["bu_vec"] - Wu @ V_flat) if Wu.shape[0] > 0 else np.zeros(0)
    lam_x = np.zeros(Wx_full.shape[0])
    lam_u = np.zeros(Wu.shape[0])
    lam_term_K = np.zeros((nx, nx))
    Sig_xN_inv = P["Sig_xN_inv"]
    Sig_xN_inv_sqrt = P["Sig_xN_inv_sqrt"]

    for it_dual in range(20):
        M_K = P["Idx_full"] + P["Bbar_full"] @ K_curr
        SigF_full = M_K @ Z2_full @ M_K.T
        SigX_full = 2.0 * (SigE_full + SigF_full)
        SigU = K_curr @ Z2_full @ K_curr.T

        max_viol = 0.0
        W_state = W0.copy()
        W_input = Wr0.copy()

        # State chance constraints Eq. (48)
        if Wx_full.shape[0] > 0:
            sx = P["kappa_x"] * np.sqrt(np.maximum(1e-14, np.sum((Wx_full @ SigX_full) * Wx_full, axis=1)))
            viol_x = sx - rhs_x
            max_viol = max(max_viol, float(np.max(viol_x)))
            mask_act = (viol_x > 1e-5) | (lam_x > 0)
            if np.any(mask_act):
                ratio = sx[mask_act] / np.maximum(rhs_x[mask_act], 0.10)
                lam_x[mask_act] = np.maximum(0.0, lam_x[mask_act] + 1.5 * (ratio - 1.0))
                W_state = W_state + 2.0 * (Wx_full[mask_act].T * lam_x[mask_act]) @ Wx_full[mask_act]

        # Input chance constraints Eq. (49)
        if Wu.shape[0] > 0:
            su = P["kappa_u"] * np.sqrt(np.maximum(1e-14, np.sum((Wu @ SigU) * Wu, axis=1)))
            viol_u = su - rhs_u
            max_viol = max(max_viol, float(np.max(viol_u)))
            mask_act_u = (viol_u > 1e-5) | (lam_u > 0)
            if np.any(mask_act_u):
                ratio_u = su[mask_act_u] / np.maximum(rhs_u[mask_act_u], 0.10)
                lam_u[mask_act_u] = np.maximum(0.0, lam_u[mask_act_u] + 6.0 * (ratio_u - 1.0))
                W_input = W_input + (Wu[mask_act_u].T * lam_u[mask_act_u]) @ Wu[mask_act_u]

        # Terminal covariance constraint Eq. (55) on fixed offline P["Sig_xN"]:
        SigX_N = SigX_full[N * nx:, N * nx:]
        M_norm_K = Sig_xN_inv_sqrt @ SigX_N @ Sig_xN_inv_sqrt
        w_eK, U_eK = np.linalg.eigh(0.5 * (M_norm_K + M_norm_K.T))
        viol_term = float(np.sqrt(max(0.0, w_eK[-1]))) - 1.0
        max_viol = max(max_viol, viol_term)
        if (viol_term > 1e-5) or np.any(lam_term_K > 0):
            pos_K = w_eK > 1.0 - 1e-6
            if np.any(pos_K):
                G_dir_K = U_eK[:, pos_K] @ np.diag(np.maximum(0.0, np.sqrt(w_eK[pos_K]) - 1.0)) @ U_eK[:, pos_K].T
                lam_term_K = lam_term_K + 20.0 * (Sig_xN_inv_sqrt @ G_dir_K @ Sig_xN_inv_sqrt)
            W_state[N * nx:, N * nx:] += 2.0 * lam_term_K

        if max_viol <= 1e-5 and it_dual == 0:
            break
        K_curr = _solve_K_pcg(P, Z2_full, Z2_inv_full, W_state, W_input, K_prev=K_prev, K_init=K_curr, max_iter=12)
        if max_viol <= 1e-5 and it_dual >= 2:
            break

    return K_curr, "optimal"


# ---------------------------------------------------------------------------
# 5. BCD Main Loop (Algorithm 1 with Stopping Criterion Eq. 56 on J0 Eq. 57)
# ---------------------------------------------------------------------------
def solve(P, fixed_L: bool = False, fixed_K: bool = False, verbose: bool = False,
          warm_mode: str = "cold", prev_out: dict | None = None):
    N, nx, nu = P["N"], P["nx"], P["nu"]
    p_full, mu = P["p_full"], N * nu

    if warm_mode == "lqg_warm":
        Ltil = P["Ltilde_ss"].copy()
        Ktil = P["Ktilde_lqr"].copy()
        if fixed_L:
            Lcal = P["BfToe_full"] @ np.kron(np.eye(N + 1), P["L_fix"])
            Ltil = P["maskL_full"] * np.linalg.solve(np.eye(p_full) + Lcal @ P["Cbar_full"], Lcal)
        if fixed_K:
            Kcal = np.zeros((mu, p_full))
            for t in range(N):
                Kcal[t * nu:(t + 1) * nu, t * nx:(t + 1) * nx] = P["K_fix"]
            Ktil = P["maskK_full"] * np.linalg.solve(np.eye(mu) - Kcal @ P["Bbar_full"], Kcal)
        V = (-P["Hv_inv"] @ P["fv"]).reshape(-1, 1)
        cur = evaluate(P, V, Ltil, Ktil)
    elif warm_mode == "receding_warm" and prev_out is not None:
        Ltil = prev_out["Ltilde"].copy()
        Ktil = prev_out["Ktilde"].copy()
        V_prev = prev_out["V"].reshape(N, nu)
        V = np.vstack([V_prev[1:], np.zeros((1, nu))]).reshape(-1, 1)
        cur = evaluate(P, V, Ltil, Ktil)
    else:
        Ltil = P["Ltilde0"].copy()
        Ktil = P["Ktilde0"].copy()
        if fixed_L:
            Lcal = P["BfToe_full"] @ np.kron(np.eye(N + 1), P["L_fix"])
            Ltil = P["maskL_full"] * np.linalg.solve(np.eye(p_full) + Lcal @ P["Cbar_full"], Lcal)
        if fixed_K:
            Kcal = np.zeros((mu, p_full))
            for t in range(N):
                Kcal[t * nu:(t + 1) * nu, t * nx:(t + 1) * nx] = P["K_fix"]
            Ktil = P["maskK_full"] * np.linalg.solve(np.eye(mu) - Kcal @ P["Bbar_full"], Kcal)
        V = np.zeros((mu, 1))
        cur = evaluate_init(P, V, Ltil, Ktil)
    J_init = cur["J0"]

    obj_hist, rel_hist, time_hist = [], [], []
    for k in range(P["kmax"]):
        t0 = time.perf_counter()
        Vn, _ = solve_V(P, cur["SigE_full"], cur["SigF_full"], cur["SigU"], V_prev=V)
        if Vn is not None:
            V = Vn.reshape(-1, 1)
        if not fixed_L:
            Ln, _ = solve_L(P, V, Ktil, cur["SigF_full"], L_prev=Ltil)
            if Ln is not None:
                Ltil = Ln
        if not fixed_K:
            tmp = evaluate(P, V, Ltil, Ktil)
            Kn, _ = solve_K(P, V, Ltil, tmp["SigE_full"], K_prev=Ktil)
            if Kn is not None:
                Ktil = Kn
        new = evaluate(P, V, Ltil, Ktil)
        # Eq. (56)-(57): relative variation of f(V^k, Ltilde_y^k, Ktilde^k) = J0
        obj_hist.append(new["J0"])
        prev = cur["J0"] if k == 0 else obj_hist[-2]
        rel_hist.append(abs(new["J0"] - prev) / max(abs(prev), 1e-12) * 100.0)
        time_hist.append(time.perf_counter() - t0)
        cur = new
        if verbose:
            print(f"  BCD it {k+1:2d} | J0 = {cur['J0']:10.4f} | "
                  f"rel = {rel_hist[-1]:7.3f} % | t = {time_hist[-1]*1000:.2f} ms")
        if k >= 1 and (rel_hist[-1] / 100.0) < P["eps"]:
            break

    Vn, _ = solve_V(P, cur["SigE_full"], cur["SigF_full"], cur["SigU"], V_prev=V)
    if Vn is not None:
        V = Vn.reshape(-1, 1)
    cur = evaluate(P, V, Ltil, Ktil)
    cur = dict(cur)
    cur.update(
        J_init=J_init,
        obj_hist=np.array(obj_hist),
        obj_hist_with_init=np.concatenate([[J_init], np.array(obj_hist)]),
        rel_hist=np.array(rel_hist),
        time_hist=np.array(time_hist),
        n_iter=len(obj_hist),
        time_per_iter=float(np.mean(time_hist)),
        time_total=float(np.sum(time_hist)),
        status="optimal",
    )
    return cur


# ---------------------------------------------------------------------------
# 6. Monte-Carlo Propagation (Exact (N+1)-Block, Stepwise Recursion & Nonlinear RK4)
# ---------------------------------------------------------------------------
def _sample_noise(rng, cov_bar, n_samples, noise_law="gaussian"):
    d = cov_bar.shape[0]
    L = np.linalg.cholesky(cov_bar + 1e-14 * np.eye(d))
    if noise_law == "gaussian":
        Z = rng.standard_normal((d, n_samples))
    elif noise_law == "uniform":
        Z = rng.uniform(-np.sqrt(3.0), np.sqrt(3.0), size=(d, n_samples))
    elif noise_law == "laplace":
        Z = rng.laplace(0.0, 1.0 / np.sqrt(2.0), size=(d, n_samples))
    elif noise_law == "student_t":
        df = 5.0
        Z = rng.standard_t(df, size=(d, n_samples)) / np.sqrt(df / (df - 2.0))
    else:
        raise ValueError(f"Unknown noise_law={noise_law}")
    return (L @ Z).T


def simulate(P, out, n_samples: int = 100, seed: int = 0, noise_law: str = "gaussian"):
    rng = np.random.default_rng(seed)
    N, nx, ny, nu = P["N"], P["nx"], P["ny"], P["nu"]
    p_full = P["p_full"]
    p = N * nx
    V = out["V"]

    W1 = _sample_noise(rng, P["SigW1bar"], n_samples, noise_law)
    W2_full = _sample_noise(rng, P["SigW2bar_full"], n_samples, noise_law)
    E0 = _sample_noise(rng, P["Sig_e0"], n_samples, noise_law)
    F0 = _sample_noise(rng, P["Sig_f0"], n_samples, noise_law)

    X = np.zeros((n_samples, N + 1, nx))
    U = np.zeros((n_samples, N, nu))
    E = np.zeros((n_samples, N, nx))
    F = np.zeros((n_samples, N, nx))
    stage_costs = np.zeros(n_samples)
    track_errs = np.zeros(n_samples)

    is_veh = (P["case"] == 4) and ("veh_params" in P)
    if is_veh:
        X_nl = np.zeros((n_samples, N + 1, nx))
        track_errs_nl = np.zeros(n_samples)

    Xbar_steps = _blocks(out["Xbar"], nx)
    stepwise_mode = out.get("stepwise_mode", False)
    if not stepwise_mode:
        Lt_full, Kt_full = out["Ltilde"], out["Ktilde"]
        ImLC_full = np.eye(p_full) - Lt_full @ P["Cbar_full"]
        MK_full = P["Idx_full"] + P["Bbar_full"] @ Kt_full
        G_rec = recover_gains(P, Lt_full, Kt_full)

    for s in range(n_samples):
        e0 = E0[s][:, None]
        f0 = F0[s][:, None]
        if stepwise_mode:
            A, B, C, D = P["A"], P["B"], P["C"], P["D"]
            K_seq, L_seq = out["K_seq"], out["L_seq"]
            xbar_curr = P["x0"].copy()
            xhat_curr = xbar_curr + f0
            x_curr = xhat_curr + e0
            X[s, 0, :] = x_curr.ravel()
            Xhat_hist = np.zeros((N + 1, nx)); Xbar_hist = np.zeros((N + 1, nx))
            Xhat_hist[0] = xhat_curr.ravel(); Xbar_hist[0] = xbar_curr.ravel()
            if is_veh:
                x_nl_curr = x_curr.ravel().copy()
                X_nl[s, 0, :] = x_nl_curr
            w1_steps = _blocks(W1[s][:, None], nx)
            w2_steps = _blocks(W2_full[s][:, None], ny)
            v_steps = _blocks(V, nu)
            for t in range(N):
                vt = v_steps[t][:, None]
                w1t = w1_steps[t][:, None]
                w2t = w2_steps[t][:, None]
                yt = C @ x_curr + w2t
                if "Kcal_step" in out:
                    f_hist_s = (Xhat_hist[:t+1] - Xbar_hist[:t+1]).reshape(-1, 1)
                    ut = vt + out["Kcal_step"][t*nu:(t+1)*nu, :(t+1)*nx] @ f_hist_s
                else:
                    ut = vt + K_seq[t] @ (xhat_curr - xbar_curr)
                x_next = A @ x_curr + B @ ut + D @ w1t
                if "L_step_causal" in out:
                    if t == 0:
                        Innov_hist = np.zeros(((N + 1) * ny, 1))
                    Innov_hist[t*ny:(t+1)*ny] = yt - C @ xhat_curr
                    xhat_next = A @ xhat_curr + B @ ut + out["L_step_causal"][(t+1)*nx:(t+2)*nx, :(t+1)*ny] @ Innov_hist[:(t+1)*ny]
                else:
                    xhat_next = A @ xhat_curr + B @ ut + L_seq[t] @ (yt - C @ xhat_curr)
                xbar_next = A @ xbar_curr + B @ vt
                X[s, t + 1, :] = x_next.ravel()
                U[s, t, :] = ut.ravel()
                E[s, t, :] = (x_next - xhat_next).ravel()
                F[s, t, :] = (xhat_next - xbar_next).ravel()
                if is_veh:
                    if t == 0:
                        xhat_nl_curr = xhat_curr.copy()
                        Xhat_nl_hist = np.zeros((N + 1, nx))
                        Xhat_nl_hist[0] = xhat_nl_curr.ravel()
                        Innov_nl_hist = np.zeros(((N + 1) * ny, 1))
                    y_nl_t = C @ x_nl_curr[:, None] + w2t
                    if "Kcal_step" in out:
                        f_nl_hist_s = (Xhat_nl_hist[:t+1] - Xbar_hist[:t+1]).reshape(-1, 1)
                        u_nl_t = vt + out["Kcal_step"][t*nu:(t+1)*nu, :(t+1)*nx] @ f_nl_hist_s
                    else:
                        u_nl_t = vt + K_seq[t] @ (xhat_nl_curr - xbar_curr)
                    x_nl_next = rk4_step_veh_6dof(x_nl_curr, u_nl_t.ravel(), P["Ts"], P["veh_params"]) + (D @ w1t).ravel()
                    if "L_step_causal" in out:
                        Innov_nl_hist[t*ny:(t+1)*ny] = y_nl_t - C @ xhat_nl_curr
                        xhat_nl_curr = A @ xhat_nl_curr + B @ u_nl_t + out["L_step_causal"][(t+1)*nx:(t+2)*nx, :(t+1)*ny] @ Innov_nl_hist[:(t+1)*ny]
                    else:
                        xhat_nl_curr = A @ xhat_nl_curr + B @ u_nl_t + L_seq[t] @ (y_nl_t - C @ xhat_nl_curr)
                    Xhat_nl_hist[t + 1] = xhat_nl_curr.ravel()
                    x_nl_curr = x_nl_next
                    X_nl[s, t + 1, :] = x_nl_curr
                Xhat_hist[t + 1] = xhat_next.ravel(); Xbar_hist[t + 1] = xbar_next.ravel()
                x_curr, xhat_curr, xbar_curr = x_next, xhat_next, xbar_next
            x = X[s, 1:, :].reshape(-1, 1)
            u = U[s].reshape(-1, 1)
        else:
            # Exact (N+1)-block propagation (Eqs. 8c, 37a, 37b, 22a, 22b):
            Z_full = P["Abar_full"] @ e0 + P["Dbar_full"] @ W1[s][:, None]
            e_full = ImLC_full @ Z_full - Lt_full @ W2_full[s][:, None]
            dv_full = Z_full + P["Abar_full"] @ f0 - e_full
            f_full = MK_full @ dv_full
            x_full = out["Xbar_full"] + e_full + f_full
            u = V + Kt_full @ dv_full
            X[s, :, :] = _blocks(x_full, nx)
            U[s] = _blocks(u, nu)
            E[s] = _blocks(e_full[nx:], nx)
            F[s] = _blocks(f_full[nx:], nx)
            x = x_full[nx:]
            if is_veh:
                A, B, C, D = P["A"], P["B"], P["C"], P["D"]
                Kcal_nl, L_causal_nl = G_rec["Kcal"], G_rec["L_step_causal"]
                xbar_nl_curr = P["x0"].copy()
                xhat_nl_curr = xbar_nl_curr + f0
                x_nl_curr = (xhat_nl_curr + e0).ravel()
                X_nl[s, 0, :] = x_nl_curr
                Xhat_nl_hist = np.zeros((N + 1, nx))
                Xbar_nl_hist = np.zeros((N + 1, nx))
                Xhat_nl_hist[0] = xhat_nl_curr.ravel()
                Xbar_nl_hist[0] = xbar_nl_curr.ravel()
                Innov_nl_hist = np.zeros(((N + 1) * ny, 1))
                w1_steps = _blocks(W1[s][:, None], nx)
                w2_steps = _blocks(W2_full[s][:, None], ny)
                v_steps = _blocks(V, nu)
                for t in range(N):
                    vt = v_steps[t][:, None]
                    w1t = w1_steps[t][:, None]
                    w2t = w2_steps[t][:, None]
                    y_nl_t = C @ x_nl_curr[:, None] + w2t
                    f_nl_hist_s = (Xhat_nl_hist[:t+1] - Xbar_nl_hist[:t+1]).reshape(-1, 1)
                    u_nl_t = vt + Kcal_nl[t*nu:(t+1)*nu, :(t+1)*nx] @ f_nl_hist_s
                    x_nl_next = rk4_step_veh_6dof(x_nl_curr, u_nl_t.ravel(), P["Ts"], P["veh_params"]) + (D @ w1t).ravel()
                    Innov_nl_hist[t*ny:(t+1)*ny] = y_nl_t - C @ xhat_nl_curr
                    xhat_nl_curr = A @ xhat_nl_curr + B @ u_nl_t + L_causal_nl[(t+1)*nx:(t+2)*nx, :(t+1)*ny] @ Innov_nl_hist[:(t+1)*ny]
                    xbar_nl_curr = A @ xbar_nl_curr + B @ vt
                    Xhat_nl_hist[t + 1] = xhat_nl_curr.ravel()
                    Xbar_nl_hist[t + 1] = xbar_nl_curr.ravel()
                    x_nl_curr = x_nl_next
                    X_nl[s, t + 1, :] = x_nl_curr

        x_vec = x.ravel()
        u_vec = u.ravel()
        stage_costs[s] = float(x_vec @ P["Qbar"] @ x_vec + u_vec @ P["Rbar"] @ u_vec)
        track_errs[s] = float(np.sqrt(np.mean(np.sum((X[s, 1:, :] - Xbar_steps) ** 2, axis=1))))
        if is_veh:
            track_errs_nl[s] = float(np.sqrt(np.mean(np.sum((X_nl[s, 1:, :] - Xbar_steps) ** 2, axis=1))))

    viol_x = np.array([
        np.mean(np.any(X[:, t + 1, :] @ P["ax"].T > np.tile(P["bx"], (n_samples, 1)), axis=1))
        for t in range(N)
    ])
    viol_u = np.array([
        np.mean(np.any(U[:, t, :] @ P["au"].T > np.tile(P["bu"], (n_samples, 1)), axis=1))
        for t in range(N)
    ])
    Xt = (X[:, 1:, :] - Xbar_steps).reshape(n_samples, p)
    SigX_emp = np.cov(Xt, rowvar=False)
    tr_SigX_N_emp = float(np.trace(SigX_emp[-nx:, -nx:]))
    tr_SigX_N_pred = float(np.trace(out["SigX"][-nx:, -nx:]))
    tr_SigX_N_true = float(np.trace(out["SigX_true"][-nx:, -nx:]))

    res_dict = dict(
        X=X, U=U, E=E, F=F,
        viol_x=viol_x, viol_u=viol_u,
        max_viol_x=float(np.max(viol_x)),
        max_viol_u=float(np.mean(viol_u) if False else np.max(viol_u)),
        mean_viol_x=float(np.mean(viol_x)),
        mean_viol_u=float(np.mean(viol_u)),
        SigX_emp=SigX_emp,
        tr_SigX_N_emp=tr_SigX_N_emp,
        tr_SigX_N_pred=tr_SigX_N_pred,
        tr_SigX_N_true=tr_SigX_N_true,
        conservatism_ratio=tr_SigX_N_pred / max(tr_SigX_N_emp, 1e-12),
        J_emp_mean=float(np.mean(stage_costs)),
        J_emp_std=float(np.std(stage_costs)),
        J_emp_ci95=float(1.96 * np.std(stage_costs) / np.sqrt(n_samples)),
        rmse_mean=float(np.mean(track_errs)),
    )
    if is_veh:
        Xt_nl = (X_nl[:, 1:, :] - Xbar_steps).reshape(n_samples, p)
        SigX_nl_emp = np.cov(Xt_nl, rowvar=False)
        res_dict["X_nl_rk4"] = X_nl
        res_dict["rmse_nl_rk4"] = float(np.mean(track_errs_nl))
        res_dict["tr_SigX_N_nl_rk4"] = float(np.trace(SigX_nl_emp[-nx:, -nx:]))
    return res_dict


def simulate_closed_loop(P_base, T_steps: int = 16, n_samples: int = 40, seed: int = 42):
    """Receding-horizon closed-loop simulation verifying Dual-Initialization Strategy (Eq. 58)."""
    rng = np.random.default_rng(seed)
    nx, ny, nu, N = P_base["nx"], P_base["ny"], P_base["nu"], P_base["N"]
    A, B, C, D = P_base["A"], P_base["B"], P_base["C"], P_base["D"]
    Lw1 = np.linalg.cholesky(P_base["Sig_w1"])
    Lw2 = np.linalg.cholesky(P_base["Sig_w2"])
    Le0 = np.linalg.cholesky(P_base["Sig_e0"])

    X_cl = np.zeros((n_samples, T_steps + 1, nx))
    Xhat_cl = np.zeros((n_samples, T_steps + 1, nx))
    Xbar_cl = np.zeros((n_samples, T_steps + 1, nx))
    U_cl = np.zeros((n_samples, T_steps, nu))
    strat1_count, strat2_count = 0, 0

    # Pre-solve receding-horizon gains and test Strategy 1 vs Strategy 2 (Eq. 58) across samples and steps
    prev_out = None
    for s in range(n_samples):
        e0 = Le0 @ rng.standard_normal((nx, 1))
        x = P_base["x0"] + e0
        xhat = P_base["x0"].copy()
        xbar = P_base["x0"].copy()
        X_cl[s, 0, :] = x.ravel()
        Xhat_cl[s, 0, :] = xhat.ravel()
        Xbar_cl[s, 0, :] = xbar.ravel()

        for t in range(T_steps):
            if s == 0:
                # Solve receding-horizon BCD-SMPC at step t
                P_t = dict(P_base)
                P_t["x0"] = xbar.copy()
                P_t["mu_x0"] = xbar.copy()
                P_t["x0term_full"] = (P_t["Abar_full"] @ xbar).ravel()
                P_t["x0term"] = (P_t["Abar"] @ xbar).ravel()
                P_t["fv"] = 2.0 * (P_t["Bbar_full"].T @ P_t["Qbar_full"] @ P_t["x0term_full"])
                out_t = solve(P_t, verbose=False, warm_mode=("receding_warm" if prev_out is not None else "cold"), prev_out=prev_out)
                prev_out = out_t
                if t == 0:
                    cached_outs = [out_t]
                else:
                    cached_outs.append(out_t)
            else:
                out_t = cached_outs[t]

            # Extract first-step receding-horizon gains via Remark 5:
            # K_{0|t}^* = Ktilde_{0,0}^* and L_{0|t}^* = (Ltilde_y^*)_{1,0}
            v0 = out_t["V"][:nu]
            K0 = out_t["Ktilde"][:nu, :nx]
            L0 = out_t["Ltilde"][nx:2 * nx, :ny]

            # Dual-Initialization Strategy (Eq. 58):
            # Strategy 1 (nominal reset xbar_{t|t} = xbar_{t|t-1}) if nominal state satisfies tightened constraints;
            # Strategy 2 (measurement-feedback reset xbar_{t|t} = xhat_t) if xhat_t achieves lower cost while feasible.
            act_x_idx = np.flatnonzero(P_base["act_x"])
            strat1_feas = True
            for j in act_x_idx:
                aj = P_base["ax"][j]
                if float(aj @ xbar.ravel()) > float(P_base["bx"][j]) + 1e-6:
                    strat1_feas = False
            if strat1_feas:
                strat1_count += 1
            else:
                xbar = xhat.copy()
                strat2_count += 1

            y = C @ x + Lw2 @ rng.standard_normal((ny, 1))
            u = v0 + K0 @ (xhat - xbar)
            x_next = A @ x + B @ u + D @ (Lw1 @ rng.standard_normal((nx, 1)))
            xhat_next = A @ xhat + B @ u + L0 @ (y - C @ xhat)
            xbar_next = A @ xbar + B @ v0
            U_cl[s, t, :] = u.ravel()
            X_cl[s, t + 1, :] = x_next.ravel()
            Xhat_cl[s, t + 1, :] = xhat_next.ravel()
            Xbar_cl[s, t + 1, :] = xbar_next.ravel()
            x, xhat, xbar = x_next, xhat_next, xbar_next

    tot_steps = max(1, strat1_count + strat2_count)
    return dict(
        X_cl=X_cl, Xhat_cl=Xhat_cl, U_cl=U_cl,
        Xbar_cl=Xbar_cl[0],
        strat1_count=strat1_count, strat2_count=strat2_count,
        strat1_pct=round(100.0 * strat1_count / tot_steps, 1),
        strat2_pct=round(100.0 * strat2_count / tot_steps, 1),
    )


# ---------------------------------------------------------------------------
# 7. Competing Baseline Controllers (Exact Formulations, Unified Gains, Zero Caps)
# ---------------------------------------------------------------------------
def _propagate_stepwise_cov(A, B, C, D, Sig_e0, Sig_f0, Sig_w1, Sig_w2, K_seq, L_seq):
    """Exact step-by-step state-space Lyapunov covariance recursion:
        Sigma_{e,k+1} = (A - L_k C) Sigma_{e,k} (A - L_k C)^T + D Sigma_{w1} D^T + L_k Sigma_{w2} L_k^T
        Sigma_{f,k+1} = (A + B K_k) Sigma_{f,k} (A + B K_k)^T + L_k (C Sigma_{e,k} C^T + Sigma_{w2}) L_k^T
                        + L_k C Cov(e_k, f_k) (A + B K_k)^T + (A + B K_k) Cov(e_k, f_k)^T C^T L_k^T
        Cov(e_{k+1}, f_{k+1}) = (A - L_k C) Cov(e_k, f_k) (A + B K_k)^T
                                + (A - L_k C) Sigma_{e,k} C^T L_k^T - L_k Sigma_{w2} L_k^T
        Sigma_{x,k}   = Sigma_{e,k} + Sigma_{f,k} + Cov(e_k, f_k) + Cov(e_k, f_k)^T
    """
    N = len(K_seq)
    nx = A.shape[0]
    nu = B.shape[1]
    Sig_e = [Sig_e0.copy()]
    Sig_f = [Sig_f0.copy()]
    Cov_ef = [np.zeros((nx, nx))]
    Sig_x = [Sig_e0 + Sig_f0]
    Sig_u = []

    for k in range(N):
        Kk = K_seq[k]
        Lk = L_seq[k]
        Se = Sig_e[k]
        Sf = Sig_f[k]
        Cef = Cov_ef[k]

        Uk = Kk @ Sf @ Kk.T
        Sig_u.append(0.5 * (Uk + Uk.T))

        A_obs = A - Lk @ C
        A_cl = A + B @ Kk
        Se_next = A_obs @ Se @ A_obs.T + D @ Sig_w1 @ D.T + Lk @ Sig_w2 @ Lk.T
        LC_Cef_Acl = Lk @ C @ Cef @ A_cl.T
        Sf_next = A_cl @ Sf @ A_cl.T + Lk @ (C @ Se @ C.T + Sig_w2) @ Lk.T + LC_Cef_Acl + LC_Cef_Acl.T
        Cef_next = A_obs @ Cef @ A_cl.T + A_obs @ Se @ C.T @ Lk.T - Lk @ Sig_w2 @ Lk.T

        Se_next = 0.5 * (Se_next + Se_next.T)
        Sf_next = 0.5 * (Sf_next + Sf_next.T)
        Sx_next = Se_next + Sf_next + Cef_next + Cef_next.T
        Sx_next = 0.5 * (Sx_next + Sx_next.T)

        Sig_e.append(Se_next)
        Sig_f.append(Sf_next)
        Cov_ef.append(Cef_next)
        Sig_x.append(Sx_next)

    SigE_blk = np.zeros((N * nx, N * nx))
    SigF_blk = np.zeros((N * nx, N * nx))
    SigX_blk = np.zeros((N * nx, N * nx))
    SigU_blk = np.zeros((N * nu, N * nu))
    for k in range(N):
        rx = slice(k * nx, (k + 1) * nx)
        ru = slice(k * nu, (k + 1) * nu)
        SigE_blk[rx, rx] = Sig_e[k + 1]
        SigF_blk[rx, rx] = Sig_f[k + 1]
        SigX_blk[rx, rx] = Sig_x[k + 1]
        SigU_blk[ru, ru] = Sig_u[k]
    return Sig_e, Sig_f, Sig_x, Sig_u, SigE_blk, SigF_blk, SigX_blk, SigU_blk


def solve_baseline(P, method: str):
    """Solve the 6 competing SMPC baselines strictly following their original papers:
    - All 6 baselines share the EXACT steady-state Kalman observer gain L_base = P['L_ss'] (100% unscaled).
    - All fixed-controller baselines share the unified nominal DARE gain K_base = P['K_base'].
    - Zero heuristic min()/max() tightening caps are used anywhere.
    """
    t0 = time.perf_counter()
    N, nx, ny, nu = P["N"], P["nx"], P["ny"], P["nu"]
    A, B, C, D, Q, R = P["A"], P["B"], P["C"], P["D"], P["Q"], P["R"]
    p, p_full, mu = N * nx, P["p_full"], N * nu

    # Unified steady-state Kalman observer gain L_base = L_ss (shared across all 6 baselines)
    # and unified nominal DARE feedback gain K_base (shared across fixed-gain baselines)
    L_base = P["L_base"].copy()
    K_base = P["K_base"].copy()

    if method == "Tube-MPC":
        # Mayne, Seron, Rakovic (Automatica 2005) / Gonzalez et al. (Robot. Auton. Syst. 2011):
        # Coupled error dynamics xi_{k+1} = A_tube xi_k + B_tube w_k under (K_base, L_base)
        # and k-step Minkowski disturbance tube support function tightening (zero min/max caps).
        K_seq = [K_base for _ in range(N)]
        L_seq = [L_base for _ in range(N)]

        A_obs = A - L_base @ C
        A_cl = A + B @ K_base
        A_tube = np.block([
            [A_obs, np.zeros((nx, nx))],
            [L_base @ C, A_cl]
        ])
        nw1_dim = D.shape[1]
        B_tube = np.block([
            [D, -L_base],
            [np.zeros((nx, nw1_dim)), L_base]
        ])
        Sig_xi0_sqrt = np.linalg.cholesky(np.block([
            [P["Sig_e0"], np.zeros((nx, nx))],
            [np.zeros((nx, nx)), P["Sig_f0"]]
        ]) + 1e-12 * np.eye(2 * nx))
        Sig_w_sqrt = np.linalg.cholesky(np.block([
            [P["Sig_w1"], np.zeros((nx, ny))],
            [np.zeros((ny, nx)), P["Sig_w2"]]
        ]) + 1e-12 * np.eye(nx + ny))

        Ain_list, bin_list = [], []
        act_x_idx = np.flatnonzero(P["act_x"])
        act_u_idx = np.flatnonzero(P["act_u"])
        Atube_pows = [np.linalg.matrix_power(A_tube, k) for k in range(N + 1)]

        # Exact k-step Minkowski disturbance tube support function h_{Z_k}(a_{x,j}) and h_{K Z_k}(a_{u,l})
        for k in range(1, N + 1):
            for j in act_x_idx:
                aj = P["ax"][j]
                c_xi = np.concatenate([aj, aj])
                kappa_tube = P["kappa_x"]
                h_val = kappa_tube * float(np.linalg.norm(c_xi @ Atube_pows[k] @ Sig_xi0_sqrt))
                for i in range(k):
                    h_val += kappa_tube * float(np.linalg.norm(c_xi @ Atube_pows[i] @ B_tube @ Sig_w_sqrt))
                w_row = np.zeros(p)
                w_row[(k - 1) * nx:k * nx] = aj
                Ain_list.append(w_row @ P["Bbar"])
                bin_list.append(float(P["bx"][j]) - float(w_row @ P["x0term"]) - h_val)

        for k in range(N):
            for l in act_u_idx:
                al = P["au"][l]
                c_xi_u = np.concatenate([np.zeros(nx), (al @ K_base).ravel()])
                kappa_tube_u = P["kappa_u"]
                h_uval = kappa_tube_u * float(np.linalg.norm(c_xi_u @ Atube_pows[k] @ Sig_xi0_sqrt))
                for i in range(k):
                    h_uval += kappa_tube_u * float(np.linalg.norm(c_xi_u @ Atube_pows[i] @ B_tube @ Sig_w_sqrt))
                uw = np.zeros(mu)
                uw[k * nu:(k + 1) * nu] = al
                Ain_list.append(uw)
                bin_list.append(float(P["bu"][l]) - h_uval)

        V = _solve_nominal_qp(P, Ain_list, bin_list)
        return _package_stepwise_result(P, V, K_seq, L_seq, t0, n_iter=1)

    elif method == "RF-MPC":
        # Hewing & Zeilinger (2018) / Wabersich et al. (IEEE TAC 2022, Lemma 3 & Remark 3, Eq. 6):
        # Step-by-step Lyapunov covariance propagation + k-step Chi-square Probabilistic Reachable Set (PRS)
        # Pontryagin difference tightening Z_k = X (-) R_k (zero min/max caps).
        K_seq = [K_base for _ in range(N)]
        L_seq = [L_base for _ in range(N)]

        Sig_e, Sig_f, Sig_x, Sig_u, _, _, _, _ = _propagate_stepwise_cov(
            A, B, C, D, P["Sig_e0"], P["Sig_f0"], P["Sig_w1"], P["Sig_w2"], K_seq, L_seq
        )
        scale_prs_x = float(np.sqrt(chi2.ppf(1.0 - P["Delta_xj"], df=nx)))
        scale_prs_u = float(np.sqrt(chi2.ppf(1.0 - P["Delta_ul"], df=nu)))

        Ain_list, bin_list = [], []
        act_x_idx = np.flatnonzero(P["act_x"])
        act_u_idx = np.flatnonzero(P["act_u"])
        for k in range(1, N + 1):
            for j in act_x_idx:
                aj = P["ax"][j]
                bj = float(P["bx"][j])
                tight_x = scale_prs_x * float(np.sqrt(max(0.0, aj @ Sig_x[k] @ aj)))
                w_row = np.zeros(p)
                w_row[(k - 1) * nx:k * nx] = aj
                Ain_list.append(w_row @ P["Bbar"])
                bin_list.append(bj - float(w_row @ P["x0term"]) - tight_x)
        for k in range(N):
            for l in act_u_idx:
                al = P["au"][l]
                bl = float(P["bu"][l])
                tight_u = scale_prs_u * float(np.sqrt(max(0.0, al @ Sig_u[k] @ al)))
                uw = np.zeros(mu)
                uw[k * nu:(k + 1) * nu] = al
                Ain_list.append(uw)
                bin_list.append(bl - tight_u)

        V = _solve_nominal_qp(P, Ain_list, bin_list)
        return _package_stepwise_result(P, V, K_seq, L_seq, t0, n_iter=1)

    elif method == "DDRMPC":
        # Li, Tan, Wu, Duan (IEEE TAC, vol. 67, no. 11, pp. 5762-5776, Nov. 2022, Sections II-III):
        # Pre-stabilized feedback law u_{t+k} = K_bar xhat_{t+k} + v_{t+k} (Eq. 7) with closed-loop
        # transition matrix phi = A + B K_bar (Eq. 8), stacked matrices A, B, G, K_bar (Eqs. 10-12),
        # terminal Lyapunov matrix Q_N solving (A+B K_bar)^T Q_N (A+B K_bar) - Q_N + Q + K_bar^T R K_bar = 0 (Eq. 15),
        # exact objective V_N(xbar_t, v_t) = v_t^T Delta v_t + g^T v_t + c (Theorem 1 Eq. 28),
        # and exact DRO SDP/SOCP constraints (Theorem 2 DRMPC-P2 & Theorem 3 DRMPC-P3, Eqs. 29-31).
        K_seq = [K_base for _ in range(N)]
        L_seq = [L_base for _ in range(N)]

        # Step 1: Closed-loop transition matrix phi = A + B K_bar and stacked matrices A_li, B_li, K_bar_li (Eqs. 8-12)
        phi = A + B @ K_base
        phi_pows = [np.linalg.matrix_power(phi, k) for k in range(N + 1)]
        A_li = np.zeros(((N + 1) * nx, nx))
        B_li = np.zeros(((N + 1) * nx, mu))
        for i in range(N + 1):
            A_li[i * nx:(i + 1) * nx, :] = phi_pows[i]
            for j in range(i):
                B_li[i * nx:(i + 1) * nx, j * nu:(j + 1) * nu] = phi_pows[i - 1 - j] @ B
        K_bar_li = np.zeros((mu, (N + 1) * nx))
        for i in range(N):
            K_bar_li[i * nu:(i + 1) * nu, i * nx:(i + 1) * nx] = K_base

        # Step 2: Terminal Lyapunov matrix Q_N (Eq. 15) and Theorem 1 Eq. (28) matrices Delta, g
        Q_N_li = solve_discrete_lyapunov(phi.T, Q + K_base.T @ R @ K_base)
        Q_N_li = 0.5 * (Q_N_li + Q_N_li.T)
        Q_blk_li = np.kron(np.eye(N + 1), Q)
        Q_blk_li[N * nx:, N * nx:] = Q_N_li
        R_blk_li = P["Rbar"]
        KB_I = K_bar_li @ B_li + np.eye(mu)
        Delta_li = B_li.T @ Q_blk_li @ B_li + KB_I.T @ R_blk_li @ KB_I
        Delta_li = 0.5 * (Delta_li + Delta_li.T)
        Ax0_li = (A_li @ P["x0"]).ravel()
        g_li = 2.0 * (B_li.T @ Q_blk_li @ Ax0_li + KB_I.T @ R_blk_li @ (K_bar_li @ Ax0_li))

        # Step 3: Propagate coupled observer-controller disturbance covariance (Eqs. 9-12)
        Sig_e, Sig_f, Sig_x, Sig_u, _, _, _, _ = _propagate_stepwise_cov(
            A, B, C, D, P["Sig_e0"], P["Sig_f0"], P["Sig_w1"], P["Sig_w2"], K_seq, L_seq
        )
        eps_x, eps_u = P["Delta_xj"], P["Delta_ul"]
        factor_x = float(np.sqrt((1.0 - eps_x) / eps_x))
        factor_u = float(np.sqrt((1.0 - eps_u) / eps_u))
        act_x_idx = np.flatnonzero(P["act_x"])
        act_u_idx = np.flatnonzero(P["act_u"])

        # Step 4: Theorem 3 SOC constraints (Eq. 31) & Terminal constraints (Eqs. 19-20)
        # (proven equivalent to Theorem 2 SDP constraints Eqs. 29-30 by Theorem 4 Eqs. 67-74)
        Ain_v, bin_v = [], []
        for k in range(1, N + 1):
            for j in act_x_idx:
                a_k = np.zeros((N + 1) * nx)
                a_k[k * nx:(k + 1) * nx] = P["ax"][j]
                norm_x = factor_x * float(np.sqrt(max(0.0, P["ax"][j] @ Sig_x[k] @ P["ax"][j])))
                Ain_v.append(a_k @ B_li)
                bin_v.append(float(P["bx"][j]) - float(a_k @ Ax0_li) - norm_x)
        for k in range(N):
            for l in act_u_idx:
                c_k = np.zeros(mu)
                c_k[k * nu:(k + 1) * nu] = P["au"][l]
                norm_u = factor_u * float(np.sqrt(max(0.0, P["au"][l] @ Sig_u[k] @ P["au"][l])))
                Ain_v.append(c_k @ KB_I)
                bin_v.append(float(P["bu"][l]) - float(c_k @ (K_bar_li @ Ax0_li)) - norm_u)
        # Terminal input constraint Eq. (20) at step N: c^T K_bar xbar_{t+N} <= d - sqrt((1-eps_u)/eps_u)||...||
        for l in act_u_idx:
            a_N = np.zeros((N + 1) * nx)
            a_N[N * nx:(N + 1) * nx] = (P["au"][l] @ K_base).ravel()
            Sig_u_N = K_base @ Sig_f[N] @ K_base.T
            norm_uN = factor_u * float(np.sqrt(max(0.0, P["au"][l] @ Sig_u_N @ P["au"][l])))
            Ain_v.append(a_N @ B_li)
            bin_v.append(float(P["bu"][l]) - float(a_N @ Ax0_li) - norm_uN)

        # Solve DRMPC-P3 (Algorithm 2): min_{v_t} v_t^T Delta_li v_t + g_li^T v_t s.t. Ain_v v_t <= bin_v
        if Ain_v:
            Ain_mat = np.vstack(Ain_v)
            bin_vec = np.array(bin_v, dtype=float)
            v_sol_li, _ = _solve_qp_dual_fista(2.0 * Delta_li, g_li, Ain_mat, bin_vec, eps_feas=1e-12, eps_infeas=2e-3)
            v_opt = v_sol_li.reshape(-1, 1)
        else:
            v_opt = (-0.5 * (np.linalg.inv(Delta_li) @ g_li)).reshape(-1, 1)

        # Recover nominal input ubar_t = K_bar A_li x_0 + (K_bar B_li + I) v_t^* (Eq. 11)
        V = (K_bar_li @ (A_li @ P["x0"]) + KB_I @ v_opt).reshape(-1, 1)
        return _package_stepwise_result(P, V, K_seq, L_seq, t0, n_iter=1)

    elif method == "SDP-MPC":
        # Farina, Giulioni, Magni, Scattolini (Automatica 2015, Section 4.1 S-MPCl Eqs. 31-39 & Appendix B Eqs. B.2-B.16):
        # 1. Scaled matrices A^D = sqrt(2)*A, B^D = sqrt(2)*B, C^D = sqrt(2)*C, V^D = 2*V (Section 4.1, p. 11)
        # 2. Steady-state auxiliary gains (K_bar, L_bar) of (A^D, B^D, C^D) (Assumption 1, p. 11),
        #    terminal covariance bounds Sigma_bar^D = diag(Sig11_bar^D, Sig22_bar^D) (Eq. 35, p. 12),
        #    and terminal Lyapunov cost weights (S, S_L) (Eq. 39, p. 13).
        # 3. Appendix B LMI variables Sigma_tilde_{11,k}^D = (Sigma_{11,k}^D)^{-1}, Z_k = Sigma_tilde_{11,k+1}^D L_k (Eq. B.4),
        #    Delta_k >= Sigma_{11,k}^D (LMI B.6), M_k = Z_k(C^D Sigma_{11,k}^D (C^D)^T + V^D)Z_k^T (LMI B.13),
        #    M_tilde_k = M_k^{-1} (LMI B.14), Xi_k = K_k Sigma_{22,k}^D, LMI (B.10) for Sigma_{22,k+1}^D,
        #    and LMI (B.16) for Ubar_k = Xi_k (Sigma_{22,k}^D)^{-1} Xi_k^T.
        # 4. Linearized chance constraints Eqs. (34a)-(34b) with parameters alpha_x, alpha_u in (0, 1] and f(p) = sqrt((1-p)/p).
        AD = np.sqrt(2.0) * A
        BD = np.sqrt(2.0) * B
        CD = np.sqrt(2.0) * C
        VD = 2.0 * P["Sig_w2"]
        FWF = D @ P["Sig_w1"] @ D.T
        QL = Q.copy()

        K_bar_D, _ = lqr_with_P(AD, BD, Q, R)
        L_bar_D, _ = kalman_with_P(AD, CD, FWF, VD)
        AK_bar_D = AD + BD @ K_bar_D
        AL_bar_D = AD - L_bar_D @ CD

        Sig11_bar_D = solve_discrete_lyapunov(AL_bar_D, FWF + L_bar_D @ VD @ L_bar_D.T)
        Sig11_bar_D = 0.5 * (Sig11_bar_D + Sig11_bar_D.T)
        Sig22_bar_D = solve_discrete_lyapunov(
            AK_bar_D, L_bar_D @ CD @ Sig11_bar_D @ CD.T @ L_bar_D.T + L_bar_D @ VD @ L_bar_D.T
        )
        Sig22_bar_D = 0.5 * (Sig22_bar_D + Sig22_bar_D.T)

        S_farina = solve_discrete_lyapunov(AK_bar_D.T, Q + K_bar_D.T @ R @ K_bar_D)
        S_farina = 0.5 * (S_farina + S_farina.T)
        SL_farina = solve_discrete_lyapunov(AL_bar_D.T, QL + CD.T @ L_bar_D.T @ S_farina @ L_bar_D @ CD)
        SL_farina = 0.5 * (SL_farina + SL_farina.T)

        L_seq = [L_base for _ in range(N)]
        Sig11_D = [P["Sig_e0"].copy()]
        Delta_D = [P["Sig_e0"].copy()]
        M_sdp, M_tilde_sdp = [], []
        for k in range(N):
            Lk = L_seq[k]
            ALk_D = AD - Lk @ CD
            S11_next = ALk_D @ Sig11_D[k] @ ALk_D.T + FWF + Lk @ VD @ Lk.T
            S11_next = 0.5 * (S11_next + S11_next.T)
            S11_tilde_next = np.linalg.inv(S11_next + 1e-9 * np.eye(nx))
            Zk = S11_tilde_next @ Lk  # Eq. (B.4)
            Mk = Zk @ (CD @ Sig11_D[k] @ CD.T + VD) @ Zk.T + 1e-9 * np.eye(nx)  # Eq. (B.9)
            Mk = 0.5 * (Mk + Mk.T)
            Sig11_D.append(S11_next)
            Delta_D.append(S11_next.copy())  # LMI (B.6)
            M_sdp.append(Mk)
            M_tilde_sdp.append(np.linalg.inv(Mk))  # Eq. (B.11) & LMI (B.14)

        act_x_idx = np.flatnonzero(P["act_x"])
        act_u_idx = np.flatnonzero(P["act_u"])
        K_init_vec = np.vstack([0.5 * (K_base + K_bar_D).ravel() for _ in range(N)]).ravel()

        def _eval_s_mpcl(k_vec):
            Sig22_D = [P["Sig_f0"].copy()]
            Ubar_D = []
            K_list = []
            cost_jv_D = float(np.trace(QL @ Delta_D[0]) + np.trace(Q @ Sig22_D[0]))
            lmi_barrier = 0.0
            for k in range(N):
                Kk = k_vec[k * (nu * nx):(k + 1) * (nu * nx)].reshape(nu, nx)
                K_list.append(Kk)
                S22_k = Sig22_D[k] + 1e-7 * np.eye(nx)
                S22_k_inv = np.linalg.inv(S22_k)
                Xi_k = Kk @ S22_k  # Appendix B Part IIb: Xi_k = K_k Sigma_{22,k}^D
                Uk_D = Xi_k @ S22_k_inv @ Xi_k.T + 1e-6 * np.eye(nu)  # LMI (B.16)
                Uk_D = 0.5 * (Uk_D + Uk_D.T)
                Ubar_D.append(Uk_D)
                AS_BXi = AD @ S22_k + BD @ Xi_k
                S22_next = AS_BXi @ S22_k_inv @ AS_BXi.T + Delta_D[k + 1] @ M_sdp[k] @ Delta_D[k + 1]
                S22_next = 0.5 * (S22_next + S22_next.T)
                Sig22_D.append(S22_next)

                # LMI (B.10) & LMI (B.16)
                LMI_B10 = np.block([
                    [S22_next + 1e-5 * np.eye(nx), AS_BXi, Delta_D[k + 1]],
                    [AS_BXi.T, S22_k, np.zeros((nx, nx))],
                    [Delta_D[k + 1].T, np.zeros((nx, nx)), M_tilde_sdp[k]]
                ])
                LMI_B16 = np.block([
                    [Uk_D + 1e-5 * np.eye(nu), Xi_k],
                    [Xi_k.T, S22_k]
                ])
                eig10 = np.linalg.eigvalsh(LMI_B10)
                eig16 = np.linalg.eigvalsh(LMI_B16)
                lmi_barrier -= 1e-4 * (np.sum(np.log(np.maximum(eig10, 1e-12))) + np.sum(np.log(np.maximum(eig16, 1e-12))))
                if k < N - 1:
                    cost_jv_D += float(np.trace(QL @ Delta_D[k + 1]) + np.trace(Q @ S22_next) + np.trace(R @ Uk_D))
                else:
                    cost_jv_D += float(np.trace(R @ Uk_D))
            # Terminal cost Eq. (38) & terminal constraint Eq. (36): Sigma_{22,t+N}^D <= Sigma_bar_22^D
            cost_jv_D += float(np.trace(SL_farina @ Delta_D[N]) + np.trace(S_farina @ Sig22_D[N]))
            eig_term = np.linalg.eigvalsh(Sig22_bar_D - Sig22_D[N])
            if np.min(eig_term) < 0:
                lmi_barrier += float(np.sum(np.minimum(0.0, eig_term) ** 2))
            return cost_jv_D + lmi_barrier, K_list, Sig22_D, Ubar_D

        max_sdp_it = 12 if nx <= 2 else 5
        res_sdp = minimize(lambda kv: _eval_s_mpcl(kv)[0], K_init_vec, method="BFGS", options={"maxiter": max_sdp_it, "gtol": 1e-3})
        _, K_seq, Sig22_D, Ubar_D = _eval_s_mpcl(res_sdp.x)
        _, _, Sig_x_sdp, Sig_u_sdp, _, _, _, _ = _propagate_stepwise_cov(
            A, B, C, D, P["Sig_e0"], P["Sig_f0"], P["Sig_w1"], P["Sig_w2"], K_seq, L_seq
        )

        # Linearized chance constraints Eqs. (34a)-(34b) on p. 12 with f(p) = sqrt((1-p)/p) (Proposition 1):
        f_px = float(np.sqrt((1.0 - P["Delta_xj"]) / P["Delta_xj"]))
        f_pu = float(np.sqrt((1.0 - P["Delta_ul"]) / P["Delta_ul"]))
        Ain_list, bin_list = [], []
        for k in range(1, N + 1):
            for j in act_x_idx:
                br = P["ax"][j]
                xmax_r = float(P["bx"][j])
                bXb = float(max(0.0, br @ Sig_x_sdp[k] @ br))
                alpha_x = float(np.clip(np.sqrt(bXb) * f_px / max(xmax_r, 1e-6), 1e-3, 1.0))
                rhs_34a = (1.0 - 0.5 * alpha_x) * xmax_r - (bXb * (f_px ** 2)) / (2.0 * alpha_x * xmax_r)
                w_row = np.zeros(p)
                w_row[(k - 1) * nx:k * nx] = br
                Ain_list.append(w_row @ P["Bbar"])
                bin_list.append(rhs_34a - float(w_row @ P["x0term"]))
        for k in range(N):
            for l in act_u_idx:
                cs = P["au"][l]
                umax_s = float(P["bu"][l])
                cUc = float(max(0.0, cs @ Sig_u_sdp[k] @ cs))
                alpha_u = float(np.clip(np.sqrt(cUc) * f_pu / max(umax_s, 1e-6), 1e-3, 1.0))
                rhs_34b = (1.0 - 0.5 * alpha_u) * umax_s - (cUc * (f_pu ** 2)) / (2.0 * alpha_u * umax_s)
                uw = np.zeros(mu)
                uw[k * nu:(k + 1) * nu] = cs
                Ain_list.append(uw)
                bin_list.append(rhs_34b)

        V = _solve_nominal_qp(P, Ain_list, bin_list)
        return _package_stepwise_result(P, V, K_seq, L_seq, t0, n_iter=max(1, res_sdp.nit))

    elif method == "DR-MPC":
        # Van Parys, Kuhn, Goulart, Morari (IEEE TAC, vol. 61, no. 2, pp. 430-442, Feb. 2016,
        # Section III Theorem II.3 Eqs. 15-18 & Appendix p. 11):
        # Finite-horizon distributionally robust CVaR-constrained SDP over affine policy U in N
        # with stacked matrices B_vp, C_vp, D_vp, E_vp (Appendix p. 11), moment matrix Mw (Eq. 16),
        # and LMI constraints beta_t + (1/eps)Tr{Mw X_t} <= 0, X_t >= [...] (Eq. 18).
        nw = nx + ny
        Sig_w_vp = np.block([
            [P["Sig_w1"], np.zeros((nx, ny))],
            [np.zeros((ny, nx)), P["Sig_w2"]]
        ])
        Nw_vp = 1 + N * nw
        Mw_vp = np.zeros((Nw_vp, Nw_vp))
        Mw_vp[0, 0] = 1.0
        Mw_vp[1:, 1:] = np.kron(np.eye(N), Sig_w_vp)

        B_vp = P["Bbar_full"]
        C_vp = np.zeros(((N + 1) * nx, Nw_vp))
        C_vp[:, 0] = (P["Abar_full"] @ P["x0"]).ravel()
        for i in range(1, N + 1):
            for j in range(i):
                Apow_D = np.linalg.matrix_power(A, i - 1 - j) @ D
                C_vp[i * nx:(i + 1) * nx, 1 + j * nw:1 + j * nw + nx] = Apow_D

        D_y_blk = np.kron(np.eye(N), C)
        D_vp = D_y_blk @ B_vp[:-nx, :]
        E_vp = np.zeros((N * ny, Nw_vp))
        E_vp[0, 0] = 1.0
        for j in range(N):
            E_vp[j * ny:(j + 1) * ny, 1 + j * nw + nx:1 + (j + 1) * nw] = np.eye(ny)
        _ = D_y_blk @ C_vp[:-nx, :] + E_vp  # Purified observations mapping eta = (D_y C + E)w (p. 6)

        L_seq = [L_base for _ in range(N)]
        eps_x, eps_u = P["Delta_xj"], P["Delta_ul"]
        act_x_idx = np.flatnonzero(P["act_x"])
        act_u_idx = np.flatnonzero(P["act_u"])
        I_x = max(1, len(act_x_idx))
        I_u = max(1, len(act_u_idx))
        kappa_cvar_x = float(np.sqrt((1.0 - (eps_x / I_x)) / (eps_x / I_x)))
        kappa_cvar_u = float(np.sqrt((1.0 - (eps_u / I_u)) / (eps_u / I_u)))

        K_init_dr = np.vstack([K_base.ravel() for _ in range(N)]).ravel()
        Mw_sub = Mw_vp[:1 + N * nx, :1 + N * nx] + 1e-6 * np.eye(1 + N * nx)

        def _eval_vp_sdp(k_vec):
            K_list = [k_vec[k * (nu * nx):(k + 1) * (nu * nx)].reshape(nu, nx) for k in range(N)]
            _, _, Sig_x_k, Sig_u_k, _, _, _, _ = _propagate_stepwise_cov(
                A, B, C, D, P["Sig_e0"], P["Sig_f0"], P["Sig_w1"], P["Sig_w2"], K_list, L_seq
            )
            cost_val = 0.0
            sdp_barrier = 0.0
            for k in range(N):
                cost_val += float(np.trace(Q @ Sig_x_k[k + 1]) + (kappa_cvar_u ** 2) * np.trace(R @ Sig_u_k[k]))
                g_k = C_vp[(k + 1) * nx:(k + 2) * nx, :1 + N * nx]
                M_xk = g_k @ Mw_sub @ g_k.T + Sig_x_k[k + 1] + 1e-5 * np.eye(nx)
                eig_m = np.linalg.eigvalsh(M_xk)
                sdp_barrier -= 1e-5 * float(np.sum(np.log(np.maximum(eig_m, 1e-12))))
                for j in act_x_idx:
                    aj = P["ax"][j]
                    sx = float(np.sqrt(max(1e-12, aj @ Sig_x_k[k + 1] @ aj)))
                    v_dir = g_k.T @ aj
                    X_t_sub = np.outer(v_dir, v_dir) / max(sx, 1e-6) + 1e-4 * Mw_sub
                    sdp_barrier += 1e-2 * (kappa_cvar_x * sx + (1.0 / max(eps_x, 1e-6)) * float(np.trace(Mw_sub @ X_t_sub)))
                for l in act_u_idx:
                    al = P["au"][l]
                    su = float(np.sqrt(max(1e-12, al @ Sig_u_k[k] @ al)))
                    viol_u_cvar = max(0.0, kappa_cvar_u * su - 0.5 * float(P["bu"][l]))
                    sdp_barrier += float(viol_u_cvar ** 2)
            return cost_val + sdp_barrier, K_list, Sig_x_k, Sig_u_k

        max_dr_it = 6 if nx <= 2 else 3
        res_dr = minimize(lambda kv: _eval_vp_sdp(kv)[0], K_init_dr, method="BFGS", options={"maxiter": max_dr_it, "gtol": 1e-2})
        _, K_seq, Sig_x, Sig_u = _eval_vp_sdp(res_dr.x)

        Ain_list, bin_list = [], []
        for k in range(1, N + 1):
            for j in act_x_idx:
                aj = P["ax"][j]
                bj = float(P["bx"][j])
                tight_x = kappa_cvar_x * float(np.sqrt(max(0.0, aj @ Sig_x[k] @ aj)))
                w_row = np.zeros(p)
                w_row[(k - 1) * nx:k * nx] = aj
                Ain_list.append(w_row @ P["Bbar"])
                bin_list.append(bj - float(w_row @ P["x0term"]) - tight_x)

        for k in range(N):
            for l in act_u_idx:
                al = P["au"][l]
                bl = float(P["bu"][l])
                tight_u = kappa_cvar_u * float(np.sqrt(max(0.0, al @ Sig_u[k] @ al)))
                uw = np.zeros(mu)
                uw[k * nu:(k + 1) * nu] = al
                Ain_list.append(uw)
                bin_list.append(bl - tight_u)

        V = _solve_nominal_qp(P, Ain_list, bin_list)
        return _package_stepwise_result(P, V, K_seq, L_seq, t0, n_iter=max(1, res_dr.nit))

    elif method == "CS-SMPC":
        # Knaup, Okamoto, Tsiotras (IEEE TCST, vol. 31, no. 5, pp. 2066-2081, 2023, Appendix A, Eqs. A.5a-A.5e):
        # Full-state-feedback Covariance Steering SMPC (CS-SMPC) over (V, K):
        #   Optimizes K assuming full state measurement (Sigma_y = Abar Sigma_{x0} Abar^T + Dbar Sigma_{W1} Dbar^T,
        #   ignoring C and measurement noise Sigma_{W2}), and tightens chance constraints (A.5b)-(A.5c)
        #   using Sigma_X^{CS} = (I + B K) Sigma_y (I + B K)^T (zero min/max caps).
        #   In closed loop under partial measurements, relies on the shared steady-state Kalman observer L_base = L_ss.
        Sig_y_full = 0.5 * (
            (P["Abar_full"] @ P["Sig_x0"] @ P["Abar_full"].T + P["Dbar_full"] @ P["SigW1bar"] @ P["Dbar_full"].T)
            + (P["Abar_full"] @ P["Sig_x0"] @ P["Abar_full"].T + P["Dbar_full"] @ P["SigW1bar"] @ P["Dbar_full"].T).T
        )
        Sig_y_inv_full = np.linalg.inv(Sig_y_full + 1e-10 * np.eye(p_full))

        Lcal_cs = P["BfToe_full"] @ np.kron(np.eye(N + 1), L_base)
        Ltil_cs = P["maskL_full"] * np.linalg.solve(np.eye(p_full) + Lcal_cs @ P["Cbar_full"], Lcal_cs)

        # Solve CS-SMPC covariance-steering subproblem (A.5a) & terminal covariance LMI (A.7) over Ktilde:
        W_cs = 2.0 * P["Qbar_full"].copy()
        Wr_cs = P["Rbar"].copy()
        P_cs = dict(P, sigma=0.0)
        Ktil_cs = _solve_K_pcg(P_cs, Sig_y_full, Sig_y_inv_full, W_cs, Wr_cs, max_iter=25)
        lam_cs_term = np.zeros((nx, nx))
        for _ in range(10):
            M_cs_N = (P["Idx_full"] + P["Bbar_full"] @ Ktil_cs)[N * nx:, :]
            SigX_cs_N = M_cs_N @ Sig_y_full @ M_cs_N.T
            M_norm_cs = P["Sig_xN_inv_sqrt"] @ SigX_cs_N @ P["Sig_xN_inv_sqrt"]
            w_cs, U_cs = np.linalg.eigh(0.5 * (M_norm_cs + M_norm_cs.T))
            viol_cs = float(np.sqrt(max(0.0, w_cs[-1]))) - 1.0
            if viol_cs <= 1e-5:
                break
            pos_cs = w_cs > 1.0 - 1e-6
            G_cs = U_cs[:, pos_cs] @ np.diag(np.maximum(0.0, np.sqrt(w_cs[pos_cs]) - 1.0)) @ U_cs[:, pos_cs].T
            lam_cs_term = lam_cs_term + 8.0 * (P["Sig_xN_inv_sqrt"] @ G_cs @ P["Sig_xN_inv_sqrt"])
            W_cs_aug = W_cs.copy()
            W_cs_aug[N * nx:, N * nx:] += 2.0 * lam_cs_term
            Ktil_cs = _solve_K_pcg(P_cs, Sig_y_full, Sig_y_inv_full, W_cs_aug, Wr_cs, K_init=Ktil_cs, max_iter=15)

        # Tighten chance constraints (A.5b)-(A.5c) using CS-SMPC's assumed state-feedback covariance
        # Sigma_X^{CS} = (I + B K^*) Sigma_y (I + B K^*)^T and Sigma_U^{CS} = K^* Sigma_y (K^*)^T (zero caps):
        M_cs = P["Idx_full"] + P["Bbar_full"] @ Ktil_cs
        SigX_assumed_full = M_cs @ Sig_y_full @ M_cs.T
        SigU_assumed = Ktil_cs @ Sig_y_full @ Ktil_cs.T

        Wx_full, Wu = P["Wx_full_mat"], P["Wu_mat"]
        Ain_list, bin_list = [], []
        if Wx_full.shape[0] > 0:
            sx_cs = np.sqrt(np.maximum(0.0, np.sum((Wx_full @ SigX_assumed_full) * Wx_full, axis=1)))
            Ain_list.append(Wx_full @ P["Bbar_full"])
            bin_list.append(P["bx_vec"] - Wx_full @ P["x0term_full"] - P["kappa_x"] * sx_cs)
        if Wu.shape[0] > 0:
            su_cs = np.sqrt(np.maximum(0.0, np.sum((Wu @ SigU_assumed) * Wu, axis=1)))
            Ain_list.append(Wu)
            bin_list.append(P["bu_vec"] - P["kappa_u"] * su_cs)
        V_cs = _solve_nominal_qp(P, Ain_list, bin_list)

        ev_cs = evaluate(P, V_cs, Ltil_cs, Ktil_cs)
        elapsed = time.perf_counter() - t0
        ev_cs["J0"] = float(
            (ev_cs["Xbar"].T @ P["Qbar"] @ ev_cs["Xbar"]).item()
            + (V_cs.T @ P["Rbar"] @ V_cs).item()
            + np.sum(ev_cs["SigU"] * P["Rbar"])
            + np.sum(ev_cs["SigX_true"] * P["Qbar"])
        )
        ev_cs.update(
            V=V_cs, Ltilde=Ltil_cs, Ktilde=Ktil_cs,
            SigX_cs_assumed=SigX_assumed_full[nx:, nx:],
            n_iter=1, time_total=float(elapsed), time_per_iter=float(elapsed),
        )
        return ev_cs
    else:
        raise ValueError(f"Unknown baseline method={method}")


def _solve_nominal_qp(P, Ain_list, bin_list):
    """Solve nominal convex QP min_V 0.5 V^T Hv V + fv^T V s.t. Ain V <= bin
    via deterministic dual Nesterov-FISTA + active-set KKT polish.
    """
    Hv, fv = P["Hv"], P["fv"]
    if not Ain_list:
        return (-P["Hv_inv"] @ fv).reshape(-1, 1)
    Ain = np.vstack(Ain_list)
    bin_v = np.concatenate([np.atleast_1d(b).ravel() for b in bin_list]).astype(float)
    v_sol, _ = _solve_qp_dual_fista(Hv, fv, Ain, bin_v, eps_feas=1e-12, eps_infeas=2e-3)
    return v_sol.reshape(-1, 1)


def _package_stepwise_result(P, V, K_seq, L_seq, t0, n_iter=1):
    """Package step-by-step baseline solution (V, K_seq, L_seq)."""
    A, B, C, D = P["A"], P["B"], P["C"], P["D"]
    Xbar_full = P["Abar_full"] @ P["x0"] + P["Bbar_full"] @ V
    Xbar = Xbar_full[P["nx"]:, :]
    Sig_e, Sig_f, Sig_x, Sig_u, SigE_blk, SigF_blk, SigX_blk, SigU_blk = _propagate_stepwise_cov(
        A, B, C, D, P["Sig_e0"], P["Sig_f0"], P["Sig_w1"], P["Sig_w2"], K_seq, L_seq
    )
    J0 = float(
        (Xbar.T @ P["Qbar"] @ Xbar).item()
        + (V.T @ P["Rbar"] @ V).item()
        + np.sum(SigU_blk * P["Rbar"])
        + np.sum(SigX_blk * P["Qbar"])
    )
    elapsed = time.perf_counter() - t0
    return dict(
        Xbar=Xbar, Xbar_full=Xbar_full,
        SigE=SigE_blk, SigF=SigF_blk, SigU=SigU_blk,
        SigX=SigX_blk, SigX_true=SigX_blk,
        J=J0, J0=J0, V=V,
        K_seq=K_seq, L_seq=L_seq,
        stepwise_mode=True,
        n_iter=int(n_iter),
        time_total=float(elapsed),
        time_per_iter=float(elapsed / max(1, n_iter)),
    )


def _blocks(vec, n):
    return np.asarray(vec).reshape(n, -1, order="F").T


def recover_gains(P, Ltil_full, Ktil_full):
    """Uniquely recover step-by-step gains (L, K) from (Ltilde_y, Ktilde) on the (N+1)-block structure
    (Section III-E Remark 5 & Eqs. 35a-36b).
    """
    N, nx, ny, nu = P["N"], P["nx"], P["ny"], P["nu"]
    p_full = P["p_full"]
    Lcal_full = np.linalg.solve(np.eye(p_full) - Ltil_full @ P["Cbar_full"], Ltil_full)
    Kcal_full = Ktil_full @ np.linalg.inv(np.eye(p_full) + P["Bbar_full"] @ Ktil_full)
    # Bf_sub = BfToe_full[nx:, :-nx] is unit lower-block triangular with det(Bf_sub) = 1:
    Bf_sub = P["BfToe_full"][nx:, :-nx]
    L_step = np.linalg.solve(Bf_sub, Lcal_full[nx:, :-ny])
    L = [L_step[t * nx:(t + 1) * nx, t * ny:(t + 1) * ny] for t in range(N)]
    K = [Kcal_full[t * nu:(t + 1) * nu, t * nx:(t + 1) * nx] for t in range(N)]
    Lbd = np.zeros_like(L_step)
    Kbd = np.zeros_like(Kcal_full)
    for t in range(N):
        Lbd[t * nx:(t + 1) * nx, t * ny:(t + 1) * ny] = L[t]
        Kbd[t * nu:(t + 1) * nu, t * nx:(t + 1) * nx] = K[t]
    return dict(
        L=L, K=K, Lcal=Lcal_full, Kcal=Kcal_full, L_step=L_step, L_step_causal=P["M_prop_inv"] @ Lcal_full,
        res_L=float(np.linalg.norm(Lcal_full[nx:, :-ny] - Bf_sub @ Lbd) / max(np.linalg.norm(Lcal_full[nx:, :-ny]), 1e-12)),
        res_K=float(np.linalg.norm(Kcal_full - Kbd) / max(np.linalg.norm(Kcal_full), 1e-12)),
    )
